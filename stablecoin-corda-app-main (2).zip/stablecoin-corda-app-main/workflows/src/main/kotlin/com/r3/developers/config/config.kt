package com.r3.developers.config


object Config {
    var CB = "CN=QNB, OU=Banking Dept, O=QNB, L=Doha, C=QA"
    val percentages = listOf(
        "Receiver" to "98",
        "FeeReceiver1" to "1",
        "FeeReceiver2" to "1"
    )
}