package com.r3.developers.exchange.workflows

import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.token.workflows.FinalizeTokenSubFlow
import com.r3.developers.token.workflows.IssueDigitalCurrencyFlow
import com.r3.developers.token.workflows.TransferDigitalCurrencyArgs
import com.r3.developers.utils.Corda
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.stream.Collectors

data class ExchangeArgs(
    val sourceBank: String,
    val sourceWallet: String,
    val sourceSymbol: String,
    val sourceSymbolIssuer: String,
    val destinationBank: String,
    val exchangeAmount: String
)

@InitiatingFlow(protocol = "exchange-flow")
class ExchangeFlow : ClientStartableFlow {
    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO

        try {
            val (sourceBank, sourceWallet, sourceSymbol, sourceSymbolIssuer, destinationBank, exchangeAmount) = requestBody.getRequestBodyAs(
                jsonMarshallingService, ExchangeArgs::class.java
            )

            val sourceBankMember = memberLookup.lookup(MemberX500Name.parse(sourceBank))
                ?: throw CordaRuntimeException("Source Bank does not exist")

            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("Notary not found")

            val tokens = ledgerService.findUnconsumedStatesByExactType(
                DigitalCurrencyState::class.java,
                1000,
                Instant.now()
            ).results

            if (tokens.isEmpty()) {
                throw CordaRuntimeException("No token found for $sourceSymbol and wallet $sourceWallet")
            }

            //todo? filter states by minimum amount
            val filteredTokens = tokens.filter {
                it.state.contractState.walletAddress == sourceWallet
                        && it.state.contractState.symbol.lowercase() == sourceSymbol.lowercase()
            }
            if (filteredTokens.isEmpty()) {
                throw CordaRuntimeException("No token found for $sourceSymbol and wallet $sourceWallet")
            }
            filteredTokens.forEach {
                if (it.state.contractState.walletAddress == sourceWallet) {
                    totalAmount += it.state.contractState.amount
                }
            }

            remainingBalance = totalAmount - BigDecimal(exchangeAmount)

            val outputStates = mutableSetOf<DigitalCurrencyState>()

            val inputStates = filteredTokens.stream().map { it.ref }.collect(Collectors.toList())

            var digitalCurrencyInfo: DigitalCurrencyState? = null

            digitalCurrencyInfo = filteredTokens[0].state.contractState

            val receiverTokenState = DigitalCurrencyState(
                Utils.getSecureHash(MemberX500Name.parse(sourceSymbolIssuer).commonName!!, digestService),
                Utils.getSecureHash(destinationBank, digestService),
                digitalCurrencyInfo.name,
                sourceSymbol,
                BigDecimal(exchangeAmount),
                destinationBank,
                DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                listOf(sourceBankMember.ledgerKeys.first())
            )
            outputStates.add(receiverTokenState)

            if (!remainingBalance.equals(BigDecimal.ZERO)) {
                val senderTokenState = DigitalCurrencyState(
                    Utils.getSecureHash(MemberX500Name.parse(sourceSymbolIssuer).commonName!!, digestService),
                    Utils.getSecureHash(sourceWallet, digestService),
                    digitalCurrencyInfo.name,
                    sourceSymbol,
                    remainingBalance,
                    sourceWallet,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(sourceBankMember.ledgerKeys.first())
                )
                outputStates.add(senderTokenState)
            }
            val command = DigitalCurrencyCommands.Transfer(
                sender = sourceBankMember.name.toString(),
//                senderWallet = sourceWallet,
                transfers = listOf(),
//                amount = BigDecimal(exchangeAmount),
                symbol = sourceSymbol,
                command = "Transfer"
            )
            val signatories = setOf(sourceBankMember.ledgerKeys.first())

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addCommand(command)
                .addSignatories(signatories)

            val signedTransaction = txBuilder.toSignedTransaction()

            return flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf()))
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body " + requestBody + " because: " + e.message)
            throw CordaRuntimeException(e.message)
        }
    }
}
