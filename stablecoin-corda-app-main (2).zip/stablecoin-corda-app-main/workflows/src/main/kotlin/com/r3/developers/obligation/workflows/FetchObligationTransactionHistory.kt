//package com.r3.developers.obligation2.workflows
//
//import com.r3.developers.obligation.contracts.IOUCommands
//import net.corda.v5.application.crypto.DigestService
//import net.corda.v5.application.flows.ClientRequestBody
//import net.corda.v5.application.flows.ClientStartableFlow
//import net.corda.v5.application.flows.CordaInject
//import net.corda.v5.application.flows.FlowEngine
//import net.corda.v5.application.marshalling.JsonMarshallingService
//import net.corda.v5.application.membership.MemberLookup
//import net.corda.v5.application.messaging.FlowMessaging
//import net.corda.v5.base.annotations.CordaSerializable
//import net.corda.v5.base.annotations.Suspendable
//import net.corda.v5.crypto.SecureHash
//import net.corda.v5.ledger.common.NotaryLookup
//import net.corda.v5.ledger.utxo.UtxoLedgerService
//import net.corda.v5.ledger.utxo.token.selection.TokenSelection
//import org.slf4j.LoggerFactory
//import java.math.BigDecimal
//import java.time.Instant
//
//data class ObligationTransactionHistory(
//    val command: String,val borrower: String?, val lender: String?, val amount: BigDecimal,
//    val symbol: String, val linearId: String?,
//    val createdAt: Instant
//)
//
//@CordaSerializable
//data class FetchObligationTransactionHistoryArgs(val walletAddress: String)
//
//class FetchObligationTransactionHistory : ClientStartableFlow {
//
//    private companion object {
//        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
//    }
//
//    @CordaInject
//    lateinit var jsonMarshallingService: JsonMarshallingService
//
//    @CordaInject
//    lateinit var memberLookup: MemberLookup
//
//    @CordaInject
//    lateinit var flowEngine: FlowEngine
//
//    @CordaInject
//    lateinit var flowMessaging: FlowMessaging
//
//    @CordaInject
//    lateinit var ledgerService: UtxoLedgerService
//
//    @CordaInject
//    lateinit var notaryLookup: NotaryLookup
//
//    @CordaInject
//    lateinit var digestService: DigestService
//
//    @CordaInject
//    lateinit var tokenSelection: TokenSelection
//
//    @Suspendable
//    override fun call(requestBody: ClientRequestBody): String {
//        log.info("FetchObligationTransactionFlow.call() called")
//
//        try {
//            val (walletAddress) = requestBody.getRequestBodyAs(
//                jsonMarshallingService,
//                FetchObligationTransactionHistoryArgs::class.java
//            )
//
//            val resultSet = ledgerService.query("CUSTOM_QUERY3", SecureHash::class.java) // Instantiate the query
//                .setLimit(1000) // Only return 1000 records per page
//                .setCreatedTimestampLimit(Instant.now()) // Set the timestamp limit to the current time
//                .execute() // execute the query
//
//            var results = resultSet.results
//            val transactions = mutableListOf<ObligationTransactionHistory>()
//            do {
//                val pageTransactionHistories = results.flatMap { txId ->
//                    val transaction = ledgerService.findLedgerTransaction(txId)
//                    transaction?.let { tx ->
//                        val proposeHistories =
//                            tx.commands.filterIsInstance<IOUCommands.Propose>().mapNotNull { command ->
//                                if (walletAddress == command.lender || walletAddress == command.borrower) {
//                                    ObligationTransactionHistory(
//                                        lender = command.lender,
//                                        borrower = command.borrower,
//                                        amount = command.amount,
//                                        symbol = command.symbol,
//                                        command = command.command,
//                                        createdAt = tx.timeWindow.from!!,
//                                        linearId=command.linearId
//                                        )
//                                } else {
//                                    null
//                                }
//                            }
//
//                        val acceptHistories =
//                            tx.commands.filterIsInstance<IOUCommands.Issue>().mapNotNull { command ->
//                                if (walletAddress == command.lender || walletAddress == command.borrower) {
//                                    ObligationTransactionHistory(
//                                        lender = command.lender,
//                                        borrower = command.borrower,
//                                        amount = command.amount,
//                                        symbol = command.symbol,
//                                        command = command.command,
//                                        createdAt = tx.timeWindow.from!!,
//                                        linearId=command.linearId
//                                    )
//                                } else {
//                                    null
//                                }
//                            }
//
//                        val rejectHistories =
//                            tx.commands.filterIsInstance<IOUCommands.Reject>().mapNotNull { command ->
//                                if (walletAddress == command.lender || walletAddress == command.borrower) {
//                                    ObligationTransactionHistory(
//                                        lender = command.lender,
//                                        borrower = command.borrower,
//                                        amount = command.amount,
//                                        symbol = command.symbol,
//                                        command = command.command,
//                                        createdAt = tx.timeWindow.from!!,
//                                        linearId=command.linearId,
//                                    )
//                                } else {
//                                    null
//                                }
//                            }
//                        val transferHistories =
//                            tx.commands.filterIsInstance<IOUCommands.Transfer>().mapNotNull { command ->
//                                if (walletAddress == command.lender || walletAddress == command.borrower) {
//                                    ObligationTransactionHistory(
//                                        lender = command.lender,
//                                        borrower = command.borrower,
//                                        amount = command.amount,
//                                        symbol = command.symbol,
//                                        command = command.command,
//                                        createdAt = tx.timeWindow.from!!,
//                                        linearId=command.linearId,
//                                    )
//                                } else {
//                                    null
//                                }
//                            }
//                        val settleHistories =
//                            tx.commands.filterIsInstance<IOUCommands.Settle>().mapNotNull { command ->
//                                if (walletAddress == command.lender || walletAddress == command.borrower) {
//                                    ObligationTransactionHistory(
//                                        lender = command.lender,
//                                        borrower = command.borrower,
//                                        amount = command.amount,
//                                        symbol = command.symbol,
//                                        command = command.command,
//                                        createdAt = tx.timeWindow.from!!,
//                                        linearId=command.linearId
//                                    )
//                                } else {
//                                    null
//                                }
//                            }
//                        settleHistories + transferHistories + transferHistories+rejectHistories+acceptHistories+proposeHistories
//                    } ?: emptyList()
//                }
//
//                transactions.addAll(pageTransactionHistories)
//
//                if (resultSet.hasNext()) {
//                    results = resultSet.next()
//                } else {
//                    break
//                }
//            } while (true)
//
//            log.info("Total transactions processed: ${transactions.size}")
//
//            return jsonMarshallingService.format(transactions)
//
//        } catch (e: Exception) {
//            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
//            throw e
//        }
//    }
//}
