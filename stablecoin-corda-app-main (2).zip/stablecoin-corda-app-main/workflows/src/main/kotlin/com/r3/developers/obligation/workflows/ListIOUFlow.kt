package com.r3.developers.obligation.workflows

import com.r3.developers.obligation.states.IOUState
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant
import java.util.*

// A class to hold the deserialized arguments required to start the flow.
data class ListIOUFlowResults2(val issuer: SecureHash,
                              val symbol: String,
                              val amount: BigDecimal,
                              val lenders: List<Pair<String, BigDecimal>>,
                              val borrower: String,
                              val paid: BigDecimal,
                              val linearId: UUID,
                              val status: IOUState.IOUStatus
)

class ListIOUFlow: ClientStartableFlow {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }
    // Injects the JsonMarshallingService to read and populate JSON parameters.
    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        log.info("ListIOUFlow.call() called")

        // Queries the VNode's vault for unconsumed states and converts the result to a serializable DTO.
        val states = ledgerService.findUnconsumedStatesByExactType(IOUState::class.java,100, Instant.now()).results
        val results = states.map { stateAndRef ->
            ListIOUFlowResults2(
                stateAndRef.state.contractState.issuer,
                stateAndRef.state.contractState.symbol,
                stateAndRef.state.contractState.amount,
                stateAndRef.state.contractState.lenders,
                stateAndRef.state.contractState.borrower,
                stateAndRef.state.contractState.paid,
                stateAndRef.state.contractState.linearId,
                stateAndRef.state.contractState.status,
                )
        }
        // Uses the JsonMarshallingService's format() function to serialize the DTO to Json.
        return jsonMarshallingService.format(results)
    }
}
/*
RequestBody for triggering the flow via http-rpc:
{
    "clientRequestId": "list-1",
    "flowClassName": "com.r3.developers.obligation.workflows.ListIOUFlow",
    "requestBody": {}
}
*/