package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositCommands
import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import com.r3.developers.tokenized_deposit.states.TokenizedDepositStatus
import com.r3.developers.tokenized_deposit.states.getAccountType
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant


class CreateDepositFlow() : ClientStartableFlow {
    data class CreateDepositFlowArgs(
        val beneficiary: String,
        val tokenizedBalance: String,
        val commercialDepositCurrency: String,
        val tokenizedDepositCurrency: String,
        val accountNumber: String,
        val accountType: String
    )

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        log.info("CreateDepositFlow.call() called")

        try {
            val flowArgs = requestBody.getRequestBodyAs(jsonMarshallingService, CreateDepositFlowArgs::class.java)

            val TokenizedDepositID = flowArgs.accountNumber
            val TokenizedDepositStateAndRefs =
                ledgerService.findUnconsumedStatesByExactType(
                    TokenizedDepositState::class.java,
                    10,
                    Instant.now()
                ).results
            val TokenizedDepositStateAndRefsWithId =
                TokenizedDepositStateAndRefs.filter { it.state.contractState.accountNumber.equals(TokenizedDepositID) }

            if (TokenizedDepositStateAndRefsWithId.size >= 1) throw CordaRuntimeException("Multiple or zero Tokenized Deposit states with id \" + TokenizedDepositID + \" found")

            val myInfo = memberLookup.myInfo()
            // Obtain the notary.
            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("NotaryLookup can't find notary specified in flow arguments.")
            val beneficiaryMember = memberLookup.lookup(MemberX500Name.parse(flowArgs.beneficiary))
                ?: throw CordaRuntimeException("Beneficiary does not exist")

            val tokenizedDepositState = TokenizedDepositState(
                beneficiary = beneficiaryMember.name.toString(),
                bank = myInfo.name.toString(),
                tokenizedBalance = BigDecimal(flowArgs.tokenizedBalance),
                commercialDepositCurrency = flowArgs.commercialDepositCurrency,
                tokenizedDepositCurrency = flowArgs.tokenizedDepositCurrency,
                accountNumber = flowArgs.accountNumber,
                accountType = getAccountType(flowArgs.accountType),
                status = TokenizedDepositStatus.CREATED,
                participants = listOf(myInfo.ledgerKeys[0], beneficiaryMember.ledgerKeys[0])
            )

            val command = TokenizedDepositCommands.CreateDeposit(
                myInfo.name.commonName.toString(),
                beneficiaryMember.name.commonName.toString(),
                BigDecimal(flowArgs.tokenizedBalance),
                flowArgs.tokenizedDepositCurrency,
                "CreateDeposit"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(java.time.Duration.ofDays(1).toMillis()))
                .addOutputState(tokenizedDepositState)
                .addCommand(command)
                .addSignatories(tokenizedDepositState.participants)

            val signedTransaction = txBuilder.toSignedTransaction()

            return flowEngine.subFlow(
                FinalizeTokenizedDepositSubFlow(
                    signedTransaction,
                    listOf(beneficiaryMember.name)
                )
            )
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
            throw e
        }
    }
}
/*
{
    "clientRequestId": "createDeposit-1",
    "flowClassName": "com.r3.developers.tokenized_deposit.workflows.CreateDepositFlow",
    "requestBody": {
        "beneficiary":"CN=Bob, OU=Test Dept, O=R3, L=London, C=GB",
        "tokenizedBalance":"200",
        "commercialDepositCurrency":"USD",
        "tokenizedDepositCurrency":"AEDT",
"accountNumber":"1",
"accountType":"TOKENIZED_CHECKING"
    }
}
*/