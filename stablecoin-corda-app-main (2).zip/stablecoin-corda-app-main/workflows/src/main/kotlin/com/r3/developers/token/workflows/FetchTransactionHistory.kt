package com.r3.developers.token.workflows

import com.r3.developers.token.contracts.DigitalCurrencyCommands
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant

data class TransactionHistory(
    val sender: String?,
    val receiver: String?,
    val amount: BigDecimal,
    val symbol: String,
    val command: String,
    val createdAt: Instant
)

@CordaSerializable
data class FetchTransactionHistoryArgs(val walletAddress: String?)

class FetchTransactionHistory : ClientStartableFlow {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        log.info("FetchTransactionHistoryFlow.call() called")

        try {
            val (walletAddress) = requestBody.getRequestBodyAs(
                jsonMarshallingService,
                FetchTransactionHistoryArgs::class.java
            )

            val resultSet = ledgerService.query("CUSTOM_QUERY2", SecureHash::class.java)
                .setLimit(1000)
                .setCreatedTimestampLimit(Instant.now())
                .execute()

            val transactions = mutableSetOf<TransactionHistory>() // Use a set to prevent duplicates

            resultSet.results.forEach { txId ->
                val transaction = ledgerService.findLedgerTransaction(txId)
                transaction?.let { tx ->
                    val issueHistories = tx.commands.filterIsInstance<DigitalCurrencyCommands.Issue>().flatMap { command ->
                        val histories = mutableListOf<TransactionHistory>()
                        command.transfers?.forEach { transfer ->

                            if(transfer.first == walletAddress || command.sender == walletAddress || walletAddress == null){

                                histories.add(
                                    TransactionHistory(
                                        sender = command.sender,
                                        receiver = transfer.first,
                                        amount = transfer.second,
                                        symbol = command.symbol,
                                        command = "Issue",
                                        createdAt = tx.timeWindow.from!!
                                    )
                                )
                            }
                        }
                        histories}

                    val redeemHistories = tx.commands.filterIsInstance<DigitalCurrencyCommands.Redeem>().flatMap { command ->
                        val histories = mutableListOf<TransactionHistory>()
                        command.transfers?.forEach { transfer ->

                            if(transfer.first == walletAddress || command.sender == walletAddress || walletAddress == null){

                                histories.add(
                                    TransactionHistory(
                                        sender = command.sender,
                                        receiver = transfer.first,
                                        amount = transfer.second,
                                        symbol = command.symbol,
                                        command = "Redeem",
                                        createdAt = tx.timeWindow.from!!
                                    )
                                )
                            }
                        }

                        histories}

                    val transferHistories = tx.commands.filterIsInstance<DigitalCurrencyCommands.Transfer>().flatMap { command ->
                        val histories = mutableListOf<TransactionHistory>()
                        command.transfers?.forEach { transfer ->

                           if(transfer.first == walletAddress || command.sender == walletAddress || walletAddress == null){

                               histories.add(
                            TransactionHistory(
                                sender = command.sender,
                                receiver = transfer.first,
                                amount = transfer.second,
                                symbol = command.symbol,
                                command = "Transfer",
                                createdAt = tx.timeWindow.from!!
                            )
                               )
                        }
                    }
                        histories}

                    val transferByPercentageHistories = tx.commands.filterIsInstance<DigitalCurrencyCommands.TransferByPercentage>().flatMap { command ->
                        val histories = mutableListOf<TransactionHistory>()
                        command.transfers?.forEach { transfer ->
                            if (walletAddress == null || walletAddress == command.sender || transfer.first == walletAddress) {
                                histories.add(
                                    TransactionHistory(
                                        sender = command.sender,
                                        receiver = transfer.first,
                                        amount = transfer.second,
                                        symbol = command.symbol,
                                        command = "TransferByPercentage",
                                        createdAt = tx.timeWindow.from!!
                                    )
                                )
                            }
                        }
                        histories
                    }

                    transactions.addAll(issueHistories)
                    transactions.addAll(redeemHistories)
                    transactions.addAll(transferHistories)
                    transactions.addAll(transferByPercentageHistories)
                }
            }

            log.info("Total transactions processed: ${transactions.size}")

            return jsonMarshallingService.format(transactions.toList()) // Convert set to list before returning

        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
            throw e
        }
    }
}
