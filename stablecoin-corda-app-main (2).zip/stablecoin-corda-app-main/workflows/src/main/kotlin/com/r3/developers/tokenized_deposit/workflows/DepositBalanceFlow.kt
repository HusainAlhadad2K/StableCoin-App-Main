package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.time.Instant
import javax.persistence.Persistence

@CordaSerializable
data class DepositBalanceArgs(
    val accountNumber: String
)
class DepositBalanceFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var persistence: Persistence
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val flowArgs = requestBody.getRequestBodyAs(
                jsonMarshallingService, DepositBalanceArgs::class.java
            )
            val TokenizedDepositID = flowArgs.accountNumber
            val TokenizedDepositStateAndRefs =
                ledgerService.findUnconsumedStatesByExactType(
                    TokenizedDepositState::class.java,
                    10,
                    Instant.now()
                ).results
            val TokenizedDepositStateAndRefsWithId =
                TokenizedDepositStateAndRefs.filter { it.state.contractState.accountNumber.equals(TokenizedDepositID) }
            if (TokenizedDepositStateAndRefsWithId.size != 1) throw CordaRuntimeException("Multiple or zero Tokenized Deposit states with id \" + TokenizedDepositID + \" found")
            val TokenizedDepositStateAndRef = TokenizedDepositStateAndRefsWithId[0]
            val TokenizedDepositInput = TokenizedDepositStateAndRef.state.contractState
            return jsonMarshallingService.format("balance: ${TokenizedDepositInput.tokenizedBalance} ${TokenizedDepositInput.tokenizedDepositCurrency} ")
        } catch (e: Exception) {
            throw CordaRuntimeException(e.message)
        }
    }
}

/*{
    "clientRequestId": "balance-2",
    "flowClassName": "com.r3.developers.tokenized_deposit.workflows.DepositBalanceFlow",
    "requestBody": {
"accountNumber":"2"
}
}
*/