package com.r3.developers.tokenized_deposit.workflows

import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.InitiatingFlow
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.transaction.UtxoSignedTransaction
import org.slf4j.LoggerFactory

@InitiatingFlow(protocol = "finalize-tokenized-deposit--protocol")
class FinalizeTokenizedDepositSubFlow(
    private val signedTransaction: UtxoSignedTransaction,
    private val otherMembers: List<MemberX500Name>
) : SubFlow<String> {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @Suspendable
    override fun call(): String {
        log.info("FinalizeTokenizedDepositSubFlow.call() called")


        val sessionsList: List<FlowSession> = otherMembers.map { member ->
            flowMessaging.initiateFlow(member)
        }


        var result: String

        try {

            val finalizedSignedTransaction = ledgerService.finalize(
                signedTransaction,
                sessionsList
            ).transaction

            result = finalizedSignedTransaction.id.toString()
            log.info("Success! Response: $result")
        } catch (e: Exception) {
            log.warn("Finality failed", e)
            result = "Finality failed, " + e.message
        }
        return result
    }
}