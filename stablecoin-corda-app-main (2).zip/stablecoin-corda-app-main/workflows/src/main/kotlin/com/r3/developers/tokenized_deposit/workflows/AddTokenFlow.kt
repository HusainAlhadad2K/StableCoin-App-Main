package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.token.workflows.RedeemSessionArgs
import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositCommands
import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import com.r3.developers.tokenized_deposit.states.TokenizedDepositStatus
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.flows.InitiatedBy
import net.corda.v5.application.flows.ResponderFlow
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.membership.MemberInfo
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant

@InitiatedBy(protocol = "redeem-digital-currency-protocol")
class AddTokenFlow : ResponderFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @Suspendable
    override fun call(session: FlowSession) {
        var beneficiaryMember: MemberInfo? = null
        try {
            val flowArgs = session.receive(RedeemSessionArgs::class.java)

            val tokenizedDepositInputs = ledgerService.findUnconsumedStatesByExactType(
                TokenizedDepositState::class.java,
                100,
                Instant.now()
            ).results

            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("NotaryLookup can't find notary specified in flow arguments.")

            val tokenizedDeposit =
                tokenizedDepositInputs.filter { it.state.contractState.accountNumber == flowArgs.accountNumber }
            if (tokenizedDeposit.size != 1) {
                throw CordaRuntimeException("Found more or none input states")
            }
            val tokenizedDepositInput = tokenizedDeposit.first().state.contractState
            if (tokenizedDepositInput.tokenizedDepositCurrency != flowArgs.symbol)
                throw throw CordaRuntimeException("tokenized deposit currency does not match with the currency of wallet tokens.")
            beneficiaryMember = memberLookup.lookup(MemberX500Name.parse(tokenizedDepositInput.beneficiary))
                ?: throw CordaRuntimeException("Can't find beneficiary")
            val bankMember = memberLookup.lookup(MemberX500Name.parse(tokenizedDepositInput.bank))
                ?: throw CordaRuntimeException("Can't find bank")

            val newTokenizedBalance = tokenizedDepositInput.tokenizedBalance.plus(BigDecimal(flowArgs.amount))

            log.info("balances ${tokenizedDepositInput.tokenizedBalance}")

            val tokenizedDepositOutput = tokenizedDepositInput.copy(
                TokenizedDepositStatus.UPDATED,
                newTokenizedBalance
            )
            val signatories = setOf(beneficiaryMember.ledgerKeys.first(), bankMember.ledgerKeys.first())

            val command = TokenizedDepositCommands.AddToken(
                bankMember.name.toString(),
                beneficiaryMember.name.toString(),
                BigDecimal(flowArgs.amount),
                flowArgs.symbol,
                "AddTokenizedDeposit"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputState(tokenizedDeposit.first().ref)
                .addOutputState(tokenizedDepositOutput)
                .addCommand(command)
                .addSignatories(signatories)

            val signedTransaction = txBuilder.toSignedTransaction()

            log.info("receiving finality for add token")
            flowEngine.subFlow(FinalizeTokenizedDepositSubFlow(signedTransaction, listOf(bankMember.name)))
            session.send(Message(Statuses.SUCCESS, "added token"))
        } catch (e: Exception) {
            session.send(Message(Statuses.FAILED, "${e.message}"))
            log.warn("Failed to process utxo flow for session '$session' because:'${e.message}'")
            throw e
        }
    }
}