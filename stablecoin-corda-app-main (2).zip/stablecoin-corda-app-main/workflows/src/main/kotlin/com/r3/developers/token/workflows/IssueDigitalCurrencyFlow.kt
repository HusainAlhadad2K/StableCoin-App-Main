package com.r3.developers.token.workflows

import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.tokenized_deposit.workflows.Message
import com.r3.developers.tokenized_deposit.workflows.Statuses
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.*
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant

@CordaSerializable
data class IssueDigitalCurrencyArgs(
    val owner: String,
    val name: String,
    val symbol: String,
    val amount: String,
    val walletAddress: String,
    val accountNumber: String,
    val tokenizedDepositBeneficiary: String
)

@InitiatingFlow(protocol = "issue-digital-currency-protocol")
class IssueDigitalCurrencyFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val (owner, name, symbol, amount, walletAddress, tokenizedDepositId, tokenizedDepositBeneficiary) = requestBody.getRequestBodyAs(
                jsonMarshallingService,
                IssueDigitalCurrencyArgs::class.java
            )
            val tokenIssuer = memberLookup.myInfo()
//            val tokenOwner =
//                memberLookup.lookup(MemberX500Name.parse(owner)) ?: throw CordaRuntimeException("Can't find owner")
            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("Notary not found")
            val beneficiaryMember = memberLookup.lookup(MemberX500Name.parse(tokenizedDepositBeneficiary))
                ?: throw CordaRuntimeException("Can't find beneficiary member")

            val beneficiarySession = flowMessaging.initiateFlow(beneficiaryMember.name)

            beneficiarySession.send(
                IssueDigitalCurrencyArgs(
                    owner,
                    name,
                    symbol,
                    amount,
                    walletAddress,
                    tokenizedDepositId,
                    tokenizedDepositBeneficiary
                )
            )
            val response = beneficiarySession.receive(Message::class.java)

            log.info("logger ${response.status}, ${response.message}")
            if (response.status == Statuses.FAILED) {
                throw CordaRuntimeException(response.message)
            }

            val tokenState = DigitalCurrencyState(
                Utils.getSecureHash(tokenIssuer.name.commonName!!, digestService),
                Utils.getSecureHash(walletAddress, digestService),
                name,
                symbol,
                BigDecimal(amount),
                walletAddress,
                DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                listOf(tokenIssuer.ledgerKeys.first())
            )
            val command = DigitalCurrencyCommands.Issue(
                sender = tokenIssuer.name.toString(),
                symbol = symbol,
                transfers = listOf(walletAddress to BigDecimal(amount)),
                command = "IssueDigitalCurrency"
            )

            val signatories = setOf(tokenIssuer.ledgerKeys.first())

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addOutputState(tokenState)
                .addCommand(command)
                .addSignatories(signatories)

            val signedTransaction = txBuilder.toSignedTransaction()

            log.info("receiving finality for issue")
            return flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf()))
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body " + requestBody + " because: " + e.message)
            throw CordaRuntimeException(e.message)
        }
    }
}
/*{
    "clientRequestId": "issue-1",
    "flowClassName": "com.r3.developers.token.workflows.IssueDigitalCurrencyFlow",
    "requestBody": {
        "symbol": "AEDT",
        "owner": "G",
        "amount": 2000,
        "name": "D",
        "walletAddress": "G",
        "accountNumber": "1",
        "tokenizedDepositBeneficiary": "CN=Bob, OU=Test Dept, O=R3, L=London, C=GB"
    }
}
*/