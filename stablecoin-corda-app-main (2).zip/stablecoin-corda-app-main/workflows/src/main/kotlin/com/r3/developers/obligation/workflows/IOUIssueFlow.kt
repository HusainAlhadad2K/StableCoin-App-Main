package com.r3.developers.obligation.workflows

import com.r3.developers.obligation.contracts.IOUCommands
import com.r3.developers.obligation.states.IOUState
import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.token.workflows.CompleteDigitalCurrencySubFlow
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.StateRef
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.*
import java.util.stream.Collectors

// A class to hold the deserialized arguments required to start the flow.
data class IOUIssueFlowArgs(val amount: String, val lenders: List<Pair<String, BigDecimal>>, val symbol: String, val issuer: SecureHash, val borrower: String)

class IOUIssueFlow: ClientStartableFlow {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    // Injects the JsonMarshallingService to read and populate JSON parameters.
    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    // Injects the MemberLookup to look up the VNode identities.
    @CordaInject
    lateinit var memberLookup: MemberLookup

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    // FlowEngine service is required to run SubFlows.
    @CordaInject
    lateinit var flowEngine: FlowEngine
    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        log.info("IOUIssueFlow.call() called")
        try {
            // Obtain the deserialized input arguments to the flow from the requestBody.
            val flowArgs = requestBody.getRequestBodyAs(jsonMarshallingService, IOUIssueFlowArgs::class.java)
            // Get flow args from the input JSON

            val myInfo = memberLookup.myInfo()

            val iou = IOUState(
                amount = BigDecimal(flowArgs.amount),
                lenders = flowArgs.lenders,
                borrower = flowArgs.borrower,
                paid = BigDecimal.ZERO,
                linearId = UUID.randomUUID(),
                issuer = flowArgs.issuer,
                symbol = flowArgs.symbol,
                participants = listOf(myInfo.ledgerKeys[0]),
                status = IOUState.IOUStatus.ISSUED,
            )

            val totalAmount = iou.amount
            val outputStates = mutableListOf<DigitalCurrencyState>()
            val tokens = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 1000, Instant.now()).results

            val inputStates: MutableList<StateRef> = mutableListOf()

            iou.lenders.forEach { lender ->
                val walletAddress = lender.first
                val percentage = (lender.second)
                val lenderAmount = totalAmount.multiply(percentage)

                // Filter states by lender's wallet address
                val filteredTokens = tokens.filter {
                    it.state.contractState.walletAddress == walletAddress
                }
                if (filteredTokens.isEmpty()) {
                    throw CordaRuntimeException("No token found for ${iou.symbol} and wallet $walletAddress")
                }

                var totalLenderAmount = BigDecimal.ZERO
                filteredTokens.forEach {
                    if (it.state.contractState.walletAddress == walletAddress) {
                        totalLenderAmount += it.state.contractState.amount
                    }
                }

                if (totalLenderAmount < lenderAmount) {
                    throw CordaRuntimeException("Not enough balance in wallet $walletAddress!")
                }

                val remainingBalance = totalLenderAmount - lenderAmount
                val lenderInputStates = filteredTokens.stream().map { it.ref }.collect(Collectors.toList())
                inputStates.addAll(lenderInputStates)

                val digitalCurrencyInfo = filteredTokens[0].state.contractState

                val receiverTokenState = DigitalCurrencyState(
                    iou.issuer,
                    Utils.getSecureHash(iou.borrower, digestService),
                    digitalCurrencyInfo.name,
                    digitalCurrencyInfo.symbol,
                    lenderAmount,
                    iou.borrower,
                    DigitalCurrencyState.DigitalCurrencyStatus.TRANSFERED,
                    listOf(myInfo.ledgerKeys.first())
                )
                outputStates.add(receiverTokenState)
                val receiverTokenState2 = DigitalCurrencyState(
                    iou.issuer,
                    Utils.getSecureHash(iou.borrower, digestService),
                    digitalCurrencyInfo.name,
                    digitalCurrencyInfo.symbol,
                    lenderAmount,
                    iou.borrower,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(myInfo.ledgerKeys.first())
                )
                outputStates.add(receiverTokenState2)
                if (remainingBalance != BigDecimal.ZERO) {
                    val senderTokenState = DigitalCurrencyState(
                        iou.issuer,
                        Utils.getSecureHash(walletAddress, digestService),
                        digitalCurrencyInfo.name,
                        digitalCurrencyInfo.symbol,
                        remainingBalance,
                        walletAddress,
                        DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                        listOf(myInfo.ledgerKeys.first())
                    )
                    outputStates.add(senderTokenState)
                }

            }

            // Get notary from input
            val notary = notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                ?: throw CordaRuntimeException("NotaryLookup can't find notary specified in flow arguments.")

            val transferCommand = DigitalCurrencyCommands.Transfer(
                sender = null,
                transfers = listOf(iou.borrower to totalAmount),
                symbol = iou.symbol,
                command = "Transfer"
            )

            val issueCommand = IOUCommands.Issue(
                lenders = iou.lenders.map { it.first },
                borrower = iou.borrower,
                amount = iou.amount,
                symbol = iou.symbol,
                linearId = iou.linearId.toString(),
                command = "Accept"
            )

            val signatories = iou.participants.toSet()
            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addOutputState(iou)
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addCommand(issueCommand)
                .addCommand(transferCommand)
                .addSignatories(signatories)

            // Convert the transaction builder to a UTXOSignedTransaction. Verifies the content of the
            // UtxoTransactionBuilder and signs the transaction with any required signatories that belong to
            // the current node.
            val signedTransaction = txBuilder.toSignedTransaction()

            // Call FinalizeIOUSubFlow which will finalise the transaction.
            // If successful the flow will return a String of the created transaction id,
            // if not successful it will return an error message.
             flowEngine.subFlow(FinalizeIOUSubFlow(signedTransaction, listOf()))
            flowEngine.subFlow(CompleteDigitalCurrencySubFlow())

            return jsonMarshallingService.format(iou.linearId.toString())
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
            throw e
        }
    }
}
/*
{
    "amount": "1000",
    "symbol": "AEDT",
    "issuer": "SHA-256:3BC51062973C458D5A6F2D8D64A023246354AD7E064B1E4E009EC8A0699A3043",
    "lenders": [
        {
            "first": "123-456-355",
            "second": 100
        }
    ],
    "borrower": "555-666-777"
}
 */