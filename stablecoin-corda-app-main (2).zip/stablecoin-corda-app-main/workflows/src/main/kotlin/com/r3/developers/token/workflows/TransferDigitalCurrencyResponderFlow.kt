//package com.r3.developers.token.workflows
//
//import com.r3.developers.token.contracts.DigitalCurrencyCommands
//import com.r3.developers.token.states.DigitalCurrencyState
//import com.r3.developers.utils.Utils
//import net.corda.v5.application.crypto.DigestService
//import net.corda.v5.application.flows.CordaInject
//import net.corda.v5.application.flows.FlowEngine
//import net.corda.v5.application.flows.InitiatedBy
//import net.corda.v5.application.flows.ResponderFlow
//import net.corda.v5.application.marshalling.JsonMarshallingService
//import net.corda.v5.application.membership.MemberLookup
//import net.corda.v5.application.messaging.FlowSession
//import net.corda.v5.base.annotations.Suspendable
//import net.corda.v5.base.exceptions.CordaRuntimeException
//import net.corda.v5.base.types.MemberX500Name
//import net.corda.v5.ledger.common.NotaryLookup
//import net.corda.v5.ledger.utxo.UtxoLedgerService
//import net.corda.v5.ledger.utxo.token.selection.TokenClaim
//import net.corda.v5.ledger.utxo.token.selection.TokenClaimCriteria
//import net.corda.v5.ledger.utxo.token.selection.TokenSelection
//import org.slf4j.LoggerFactory
//import java.math.BigDecimal
//import java.time.Duration
//import java.time.Instant
//import java.util.*
//import java.util.stream.Collectors
//
//
//
//
//
//
//
//
//
//
//
//@InitiatedBy(protocol = "exchange-protocol")
//class TransferDigitalCurrencyResponderFlow() : ResponderFlow {
//    private companion object {
//        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
//    }
//
//    @CordaInject
//    lateinit var jsonMarshallingService: JsonMarshallingService
//
//    @CordaInject
//    lateinit var memberLookup: MemberLookup
//
//    @CordaInject
//    lateinit var notaryLookup: NotaryLookup
//
//    @CordaInject
//    lateinit var tokenSelection: TokenSelection
//
//    @CordaInject
//    lateinit var ledgerService: UtxoLedgerService
//
//    @CordaInject
//    lateinit var flowEngine: FlowEngine
//
//    @CordaInject
//    lateinit var digestService: DigestService
//    @Suspendable
//    override fun call(session: FlowSession) {
//        val flowArgs = session.receive(TransferDigitalCurrencyArgs::class.java)
//
//        var tokenClaim: TokenClaim? = null
//        var totalAmount = BigDecimal.ZERO
//        var remainingBalance = BigDecimal.ZERO
//        try {
//
//            val senderMember = memberLookup.myInfo()
//            log.info("senderMember ${senderMember.name}")
//            val receiverMember = memberLookup.lookup(MemberX500Name.parse(flowArgs.transferTo))
//                ?: throw CordaRuntimeException("Receiver does not exist")
//
//            log.info("receiverMember ${receiverMember.name}")
////            val issuerMember = memberLookup.lookup(MemberX500Name.parse(flowArgs.issuer))
////                ?: throw CordaRuntimeException("Issuer does not exist")
//            val notary =
//                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
//                    ?: throw CordaRuntimeException("Notary not found")
//
//
//
//
//
//            val tokenClaimCriteria = TokenClaimCriteria(
//                DigitalCurrencyState::class.java.name,
//                Utils.getSecureHash(issuerMember.name.commonName!!, digestService),
//                notary.name,
//                flowArgs.symbol,
//                BigDecimal(flowArgs.amount)
//            )
//
//            tokenClaim = tokenSelection.tryClaim(UUID.randomUUID().toString(), tokenClaimCriteria)
//            if (tokenClaim != null) {
//                tokenClaim.claimedTokens.forEach {
//                    totalAmount += it.amount
//                }
//
//                remainingBalance = totalAmount - BigDecimal(flowArgs.amount)
//
//                val outputStates = mutableSetOf<DigitalCurrencyState>()
//
//                //Get all input states related to the token claim
//                val inputStates = tokenClaim.claimedTokens.stream().map { it.stateRef }.collect(Collectors.toList())
//                //Get all unconsumed states for flow initiator
//                val digitalCurrencyStates = ledgerService.findUnconsumedStatesByExactType(
//                    DigitalCurrencyState::class.java,
//                    100,
//                    Instant.now()
//                ).results
//
//                var digitalCurrencyInfo: DigitalCurrencyState? = null
//
//                //Loop over all unconsumed states
//                digitalCurrencyStates.filter {
//                    //find the state that match with token claim states
//                    it.state.contractState.symbol == flowArgs.symbol && it.state.contractState.walletAddress == flowArgs.walletAddress
//                }
//
//                digitalCurrencyInfo = digitalCurrencyStates[0].state.contractState
//
//                val receiverTokenState = DigitalCurrencyState(
//                    flowArgs.issuer,
//                    Utils.getSecureHash(receiverMember.name.commonName!!, digestService),
//                    digitalCurrencyInfo.name,
//                    flowArgs.symbol,
//                    BigDecimal(flowArgs.amount),
//                    digitalCurrencyInfo.walletAddress,
//                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
//                    listOf(receiverMember.ledgerKeys.first())
//                )
//
//                outputStates.add(receiverTokenState)
//
//                if (!remainingBalance.equals(BigDecimal.ZERO)) {
//                    val senderTokenState = DigitalCurrencyState(
//                        Utils.getSecureHash(issuerMember.name.commonName!!, digestService),
//                        Utils.getSecureHash(senderMember.name.commonName!!, digestService),
//                        digitalCurrencyInfo.name,
//                        flowArgs.symbol,
//                        remainingBalance,
//                        digitalCurrencyInfo.walletAddress,
//                        DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
//                        listOf(senderMember.ledgerKeys.first())
//                    )
//                    outputStates.add(senderTokenState)
//                }
//                val command = DigitalCurrencyCommands.Transfer(
//                    sender=senderMember.name.toString(),amount=BigDecimal(flowArgs.amount),symbol=flowArgs.symbol,recipient=receiverMember.name.toString(),command="TransferDigitalCurrency")
//
//                val txBuilder = ledgerService.createTransactionBuilder()
//                    .setNotary(notary.name)
//                    .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
//                    .addInputStates(inputStates)
//                    .addOutputStates(outputStates)
//                    .addCommand(command)
//                    .addSignatories(listOf(receiverMember.ledgerKeys.first(), senderMember.ledgerKeys.first()))
//
//                val signedTransaction = txBuilder.toSignedTransaction()
//
//                flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf(receiverMember.name)))
//            } else {
//                throw CordaRuntimeException("No token found for ${flowArgs.symbol}")
//            }
//        } catch (e: Exception) {
//            throw CordaRuntimeException(e.message)
//        }
//    }
//}