package com.r3.developers.obligation.workflows

import com.r3.developers.obligation.contracts.IOUCommands
import com.r3.developers.obligation.states.IOUState
import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.token.workflows.CompleteDigitalCurrencySubFlow
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.*
import java.util.stream.Collectors

// A class to hold the deserialized arguments required to start the flow.
data class IOUSettleFlowArgs(
    val iouID: UUID,
    val amountSettle: String,
)

class IOUSettleFlow : ClientStartableFlow {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO
        var isComplete = false

        try {
            val flowArgs = requestBody.getRequestBodyAs(jsonMarshallingService, IOUSettleFlowArgs::class.java)
            val (iouID, amountSettle) = flowArgs

            var amountToSettle = BigDecimal(amountSettle)
            // Query the IOU input
            val iouStateAndRefs = ledgerService.findUnconsumedStatesByExactType(IOUState::class.java, 100, Instant.now()).results
            val iouStateAndRefsWithId = iouStateAndRefs.filter { it.state.contractState.linearId == iouID }

            if (iouStateAndRefsWithId.size != 1) throw CordaRuntimeException("Multiple or zero IOU states found with id $iouID")
            val iouStateAndRef = iouStateAndRefsWithId[0]
            val iouInput = iouStateAndRef.state.contractState

            val myInfo = memberLookup.myInfo()

            val tokens = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 100, Instant.now()).results

            // Filter states by borrower's wallet address
            val filteredTokens = tokens.filter {
                it.state.contractState.walletAddress == iouInput.borrower
            }
            if (filteredTokens.isEmpty()) {
                throw CordaRuntimeException("No token found for ${iouInput.symbol} and wallet ${iouInput.borrower}")
            }
            filteredTokens.forEach {
                if (it.state.contractState.walletAddress == iouInput.borrower) {
                    totalAmount += it.state.contractState.amount
                }
            }

            if (totalAmount < amountToSettle) {
                throw CordaRuntimeException("Not enough balance in wallet ${iouInput.borrower}!")
            }
            if (iouInput.paid + amountToSettle >= iouInput.amount) {
                amountToSettle = iouInput.amount - iouInput.paid
                isComplete = true
            }
            remainingBalance = totalAmount - amountToSettle
            val digitalCurrencyInfo = filteredTokens[0].state.contractState

            val outputStates = mutableListOf<DigitalCurrencyState>()
            val inputStates = filteredTokens.stream().map { it.ref }.collect(Collectors.toList())
            if (remainingBalance.compareTo(BigDecimal.ZERO)!=0) {
                val senderTokenState = DigitalCurrencyState(
                    iouInput.issuer,
                    Utils.getSecureHash(iouInput.borrower, digestService),
                    digitalCurrencyInfo.name,
                    digitalCurrencyInfo.symbol,
                    remainingBalance,
                    iouInput.borrower,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(myInfo.ledgerKeys.first())
                )
                outputStates.add(senderTokenState)
            }

                iouInput.lenders.forEach { lender ->
                val walletAddress = lender.first
                val percentage = lender.second
                val lenderAmount = amountToSettle.multiply(percentage)

                val receiverTokenState = DigitalCurrencyState(
                    iouInput.issuer,
                    Utils.getSecureHash(walletAddress, digestService),
                    digitalCurrencyInfo.name,
                    digitalCurrencyInfo.symbol,
                    lenderAmount,
                    walletAddress,
                    DigitalCurrencyState.DigitalCurrencyStatus.TRANSFERED,
                    listOf(myInfo.ledgerKeys.first())
                )

                outputStates.add(receiverTokenState)
                val receiverTokenState2 = DigitalCurrencyState(
                    iouInput.issuer,
                    Utils.getSecureHash(walletAddress, digestService),
                    digitalCurrencyInfo.name,
                    digitalCurrencyInfo.symbol,
                    lenderAmount,
                    walletAddress,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(myInfo.ledgerKeys.first())
                )
                outputStates.add(receiverTokenState2)

                }


            // Create the IOUState from the input arguments and member information.
            val iouOutput = iouInput.pay(amountToSettle)

            // Get notary from input
            val notary = iouStateAndRef.state.notaryName

            val settleCommand = IOUCommands.Settle(
                lenders = iouInput.lenders.map { it.first },
                borrower = iouInput.borrower,
                amount = amountToSettle,
                symbol = iouOutput.symbol,
                linearId = iouOutput.linearId.toString(),
                command = "Settle"
            )

            val transferCommand = DigitalCurrencyCommands.Transfer(
                sender = iouInput.borrower,
                transfers = iouInput.lenders.map { it.first to amountToSettle.multiply(it.second.divide(BigDecimal(100))) },
                symbol = iouInput.symbol,
                command = "Transfer"
            )
            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputState(iouStateAndRef.ref)
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addOutputState(iouOutput)
                .addCommand(settleCommand)
                .addCommand(transferCommand)
                .addSignatories(listOf(myInfo.ledgerKeys.first()))

            // Convert the transaction builder to a UTXOSignedTransaction. Verifies the content of the
            // UtxoTransactionBuilder and signs the transaction with any required signatories that belong to
            // the current node.
            val signedTransaction = txBuilder.toSignedTransaction()

            // Call FinalizeIOUSubFlow which will finalise the transaction.
            flowEngine.subFlow(FinalizeIOUSubFlow(signedTransaction, listOf()))
            flowEngine.subFlow(CompleteDigitalCurrencySubFlow())

            if (isComplete) {
                flowEngine.subFlow(CompleteIOUSubFlow())
            }

            // Return the linearId of the settled IOUState2
            return iouOutput.linearId.toString()
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
            throw e
        }
    }
}
