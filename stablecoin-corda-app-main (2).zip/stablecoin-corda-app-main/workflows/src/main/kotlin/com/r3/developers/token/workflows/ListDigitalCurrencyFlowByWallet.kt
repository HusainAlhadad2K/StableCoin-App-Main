//package com.r3.developers.token.workflows
//
//
//import com.r3.developers.token.states.DigitalCurrencyState
//import net.corda.v5.application.flows.ClientRequestBody
//import net.corda.v5.application.flows.ClientStartableFlow
//import net.corda.v5.application.flows.CordaInject
//import net.corda.v5.application.marshalling.JsonMarshallingService
//import net.corda.v5.base.annotations.CordaSerializable
//import net.corda.v5.base.annotations.Suspendable
//import net.corda.v5.crypto.SecureHash
//import net.corda.v5.ledger.utxo.UtxoLedgerService
//import org.slf4j.LoggerFactory
//import java.math.BigDecimal
//import java.time.Instant
//
//data class DigitalCurrencyStateList(
//    val issuer: SecureHash,
//    val symbol: String,
//    val amount: BigDecimal,
//    val owner: SecureHash,
//    val name: String,
//    val walletAddress: String
//)
//@CordaSerializable
//data class DigitalCurrencyStateListArgs(
//    val walletAddress: String
//)
//class ListDigitalCurrencyFlowByWallet : ClientStartableFlow {
//    private companion object {
//        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
//    }
//
//    @CordaInject
//    lateinit var jsonMarshallingService: JsonMarshallingService
//
//    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
//    @CordaInject
//    lateinit var ledgerService: UtxoLedgerService
//
//    @Suspendable
//    override fun call(requestBody: ClientRequestBody): String {
//        val ( walletAddress) = requestBody.getRequestBodyAs(
//            jsonMarshallingService,
//            DigitalCurrencyStateListArgs::class.java
//        )
//        val states = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 100, Instant.now()).results
//        val filteredTokens = states.filter {
//            it.state.contractState.walletAddress == walletAddress
//        }
//        val results = filteredTokens.map {
//            DigitalCurrencyStateList(
//                it.state.contractState.issuer,
//                it.state.contractState.symbol,
//                it.state.contractState.amount,
//                it.state.contractState.owner,
//                it.state.contractState.name,
//                it.state.contractState.walletAddress
//            )
//        }
//
//        return jsonMarshallingService.format(results)
//    }
//}
///*{
//    "clientRequestId": "list-10",
//    "flowClassName": "com.r3.developers.token.workflows.ListDigitalCurrencyFlow",
//    "requestBody": {}
//}*/