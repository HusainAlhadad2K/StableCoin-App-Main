package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositCommands
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant


data class TransactionDepositHistory(
    val sender: String?,
    val recipient: String?,
    val amount: BigDecimal,
    val symbol: String,
    val command: String,
    val createdAt: Instant
)

class GetTransactionHistoryFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val result = ledgerService.query("TokenizedDepositQuery", SecureHash::class.java)
                .setLimit(100)
                .setCreatedTimestampLimit(Instant.now())
                .execute()

            val transactions = mutableListOf<TransactionDepositHistory>()

            var results = result.results

            do {
                val pageTransactionHistories = results.flatMap { txId ->
                    val transaction = ledgerService.findLedgerTransaction(txId)
                    transaction?.let { tx ->
                        val transferTokenizedDeposit =
                            tx.commands.filterIsInstance<TokenizedDepositCommands.Transfer>().map { command ->
                                TransactionDepositHistory(
                                    sender = command.sender,
                                    recipient = command.recipient,
                                    amount = command.amount,
                                    symbol = command.symbol,
                                    command = command.command,
                                    createdAt = tx.timeWindow.from!!
                                )
                            }
                        val createTokenizedDeposit =
                            tx.commands.filterIsInstance<TokenizedDepositCommands.CreateDeposit>().map { command ->
                                TransactionDepositHistory(
                                    sender = command.sender,
                                    recipient = command.recipient,
                                    amount = command.amount,
                                    symbol = command.symbol,
                                    command = command.command,
                                    createdAt = tx.timeWindow.from!!
                                )
                            }
                        val consumeTokenizedDeposit =
                            tx.commands.filterIsInstance<TokenizedDepositCommands.ConsumeToken>().map { command ->
                                TransactionDepositHistory(
                                    sender = command.sender,
                                    recipient = command.recipient,
                                    amount = command.amount,
                                    symbol = command.symbol,
                                    command = command.command,
                                    createdAt = tx.timeWindow.from!!
                                )
                            }
                        val redeemTokenizedDeposit =
                            tx.commands.filterIsInstance<TokenizedDepositCommands.RedeemDeposit>().map { command ->
                                TransactionDepositHistory(
                                    sender = command.sender,
                                    recipient = command.recipient,
                                    amount = command.amount,
                                    symbol = command.symbol,
                                    command = command.command,
                                    createdAt = tx.timeWindow.from!!
                                )
                            }
                        val addTokenizedDeposit =
                            tx.commands.filterIsInstance<TokenizedDepositCommands.AddToken>().map { command ->
                                TransactionDepositHistory(
                                    sender = command.sender,
                                    recipient = command.recipient,
                                    amount = command.amount,
                                    symbol = command.symbol,
                                    command = command.command,
                                    createdAt = tx.timeWindow.from!!
                                )
                            }
                        transferTokenizedDeposit + createTokenizedDeposit + consumeTokenizedDeposit + redeemTokenizedDeposit + addTokenizedDeposit
                    } ?: emptyList()
                }
                transactions.addAll(pageTransactionHistories)

                if (result.hasNext()) {
                    results = result.next()
                } else {
                    break
                }
            } while (true)

            log.info("Total transactions processed: ${transactions.size}")

            return jsonMarshallingService.format(transactions)
        } catch (e: Exception) {
            throw CordaRuntimeException(e.message)
        }
    }
}