package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.states.AccountType
import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import com.r3.developers.tokenized_deposit.states.TokenizedDepositStatus
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant


data class TokenizedDepositStateList(
    val bank: String,
    val tokenizedBalance: BigDecimal,
    val beneficiary: String,
    val commercialDepositCurrency: String,
    val tokenizedDepositCurrency: String,
    val accountNumber: String,
    val accountType: AccountType,
    val status: TokenizedDepositStatus
    )

class ListDepositFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        val states =
            ledgerService.findUnconsumedStatesByExactType(TokenizedDepositState::class.java, 100, Instant.now()).results
        val results = states.map {
            TokenizedDepositStateList(
                it.state.contractState.bank,
                it.state.contractState.tokenizedBalance,
                it.state.contractState.beneficiary,
                it.state.contractState.commercialDepositCurrency,
                it.state.contractState.tokenizedDepositCurrency,
                it.state.contractState.accountNumber,
                it.state.contractState.accountType,
                it.state.contractState.status
            )
        }

        return jsonMarshallingService.format(results)
    }
}

/*{
    "clientRequestId": "list-1",
    "flowClassName": "com.r3.developers.tokenized_deposit.workflows.ListDepositFlow",
    "requestBody": {
}
}
*/