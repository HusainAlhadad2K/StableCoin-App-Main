package com.r3.developers.token.workflows

import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.util.*

class GetPublicKeyFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val tokenIssuer = memberLookup.myInfo()
            val publicKey = tokenIssuer.ledgerKeys.first()
            val encodedPublicKey = Base64.getEncoder().encodeToString(publicKey.encoded)
            return jsonMarshallingService.format(mapOf("publicKey" to encodedPublicKey))
        } catch (e: Exception) {
            log.error("Error occurred in GetPublicKeyFlow: ${e.message}", e)
            throw e
        }
    }
}
