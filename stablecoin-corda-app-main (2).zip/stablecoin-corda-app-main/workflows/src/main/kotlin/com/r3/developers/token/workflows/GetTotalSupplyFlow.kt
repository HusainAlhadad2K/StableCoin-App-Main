package com.r3.developers.token.workflows

import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.token.states.DigitalCurrencyTypeState
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant

data class DigitalCurrencySummary(
    val symbol: String,
    val issuer: String,
    val totalAmount: BigDecimal
)

class GetTotalSupplyFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        val states = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 1000, Instant.now()).results
        val typeStates = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyTypeState::class.java, 1000, Instant.now()).results

        val summaries = mutableListOf<DigitalCurrencySummary>()

        typeStates.forEach { typeState ->
            val symbol = typeState.state.contractState.symbol
            val issuer = typeState.state.contractState.issuer

            val totalAmount = states.filter { it.state.contractState.symbol == symbol }
                .fold(BigDecimal.ZERO) { sum, state ->
                    sum + state.state.contractState.amount
                }

            summaries.add(
                DigitalCurrencySummary(
                    symbol = symbol,
                    issuer = issuer,
                    totalAmount = totalAmount
                )
            )
        }
        return jsonMarshallingService.format(summaries)
    }
}
