package com.r3.developers.obligation.workflows

import com.r3.developers.obligation.contracts.IOUCommands
import com.r3.developers.obligation.states.IOUState
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.*


// A class to hold the deserialized arguments required to start the flow.
data class DeleteIOUFlowArgs(val iouID: UUID)

class DeleteIOUFlow: ClientStartableFlow {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    // Injects the JsonMarshallingService to read and populate JSON parameters.
    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    // Injects the MemberLookup to look up the VNode identities.
    @CordaInject
    lateinit var memberLookup: MemberLookup

    // Injects the UtxoLedgerService to enable the flow to make use of the Ledger API.
    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    // FlowEngine service is required to run SubFlows.
    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService
    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        log.info("IOURejectFlow.call() called")
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO
        try {
            // Obtain the deserialized input arguments to the flow from the requestBody.
            val flowArgs = requestBody.getRequestBodyAs(jsonMarshallingService, DeleteIOUFlowArgs::class.java)

            // Get flow args from the input JSON
            val iouID = flowArgs.iouID

            //query the IOU input
            val iouStateAndRefs = ledgerService.findUnconsumedStatesByExactType(IOUState::class.java,100, Instant.now()).results
            val iouStateAndRefsWithId = iouStateAndRefs.filter { it.state.contractState.linearId.equals(iouID)}

            if (iouStateAndRefsWithId.size != 1) throw CordaRuntimeException("Multiple or zero IOU states with id \" + iouID + \" found")
            val iouStateAndRef = iouStateAndRefsWithId[0]
            val iouInput = iouStateAndRef.state.contractState



            //get notary from input
            val notary = iouStateAndRef.state.notaryName


            val signatories=iouInput.participants.toSet()


            val rejectCommand = IOUCommands.Reject(
                lenders = null,
                borrower=iouInput.borrower,
                amount = iouInput.amount,
                symbol = iouInput.symbol,
                linearId = iouInput.linearId.toString(),
                command = "Reject"
            )
            val txBuilder= ledgerService.createTransactionBuilder()
                .setNotary(notary)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputState(iouStateAndRef.ref)
                .addCommand(rejectCommand)
                .addSignatories(signatories)
            // Convert the transaction builder to a UTXOSignedTransaction. Verifies the content of the
            // UtxoTransactionBuilder and signs the transaction with any required signatories that belong to
            // the current node.
            val signedTransaction = txBuilder.toSignedTransaction()

            // Call FinalizeIOUSubFlow which will finalise the transaction.
            // If successful the flow will return a String of the created transaction id,
            // if not successful it will return an error message.
             flowEngine.subFlow(FinalizeIOUSubFlow(signedTransaction, listOf()))

        }
        // Catch any exceptions, log them and rethrow the exception.
        catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body '$requestBody' because:'${e.message}'")
            throw e
        }
    return "Success"}
}
/*
RequestBody for triggering the flow via http-rpc:
{
    "clientRequestId": "settleiou-1",
    "flowClassName": "com.r3.developers.obligation.workflows.IOUSettleFlow",
    "requestBody": {
        "amountSettle":"10",
        "iouID":"4ea35048-879e-43f0-9593-343388715627"
    }
}
4ea35048-879e-43f0-9593-343388715627
*/
