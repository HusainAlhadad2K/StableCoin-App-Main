package com.r3.developers.utils

import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.membership.NotaryInfo

fun Notary(notaryLookup: NotaryLookup): NotaryInfo {
    return notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
        ?: throw CordaRuntimeException("NotaryLookup can't find notary specified in flow arguments.")
}