package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositCommands
import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.flows.SubFlow
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.time.Instant


class CloseDepositSubFlow(val accountNumber: String,val collectSignatories: List<MemberX500Name>) : SubFlow<String> {

    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @Suspendable
    override fun call(): String {
        log.info("CloseDepositSubFlow() called")

        try {

            val TokenizedDepositID = accountNumber
            val TokenizedDepositStateAndRefs =
                ledgerService.findUnconsumedStatesByExactType(TokenizedDepositState::class.java, 10, Instant.now()).results
            val TokenizedDepositStateAndRefsWithId =
                TokenizedDepositStateAndRefs.filter { it.state.contractState.accountNumber.equals(TokenizedDepositID) }
            ledgerService
            if (TokenizedDepositStateAndRefsWithId.size != 1) throw CordaRuntimeException("Multiple or zero Tokenized Deposit states with id \" + TokenizedDepositID + \" found")
            val TokenizedDepositStateAndRef = TokenizedDepositStateAndRefsWithId[0]
            val TokenizedDepositInput = TokenizedDepositStateAndRef.state.contractState


            val myInfo = memberLookup.myInfo()
            // Obtain the notary.
            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("NotaryLookup can't find notary specified in flow arguments.")
            val bankMember = memberLookup.lookup(MemberX500Name.parse(TokenizedDepositInput.bank))
                ?: throw CordaRuntimeException("Bank does not exist")


            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(java.time.Duration.ofDays(1).toMillis()))
                .addInputState(TokenizedDepositStateAndRef.ref)
                .addCommand(TokenizedDepositCommands.CloseDeposit())
                .addSignatories(TokenizedDepositInput.participants)

            val signedTransaction = txBuilder.toSignedTransaction()

            return flowEngine.subFlow(FinalizeTokenizedDepositSubFlow(signedTransaction, collectSignatories))
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow because:'${e.message}'")
            throw e
        }
    }
}

/*
{
    "clientRequestId": "redeemDeposit-1",
    "flowClassName": "com.r3.developers.tokenized_deposit.workflows.RedeemDepositFlow",
    "requestBody": {
   "linearId":"1209e254-9057-40e3-b01e-66cc3a28369d"
}
}
*/