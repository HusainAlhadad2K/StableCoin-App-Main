package com.r3.developers.token.workflows

import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenClaim
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.Map
import java.util.stream.Collectors

@CordaSerializable
data class TransferDigitalCurrencyArgs(
    val amount: String,
    val issuer: SecureHash,
    val symbol: String,
    val transferFrom: String,
    val transferTo: String
)

class TransferDigitalCurrencyFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        var tokenClaim: TokenClaim? = null
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO

        try {
            val ( amount, issuer, symbol, transferFrom, transferTo) = requestBody.getRequestBodyAs(
                jsonMarshallingService, TransferDigitalCurrencyArgs::class.java
            )

            val senderMember = memberLookup.myInfo()


            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("Notary not found")

            val tokens = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 1000, Instant.now()).results

            //todo? filter states by minimum amount
            val filteredTokens = tokens.filter {
                it.state.contractState.walletAddress == transferFrom
            }
            if(filteredTokens.isEmpty()){
                throw CordaRuntimeException("No token found for $symbol and wallet $transferFrom")
            }
            filteredTokens.forEach {
                if (it.state.contractState.walletAddress == transferFrom) {
                    totalAmount += it.state.contractState.amount
                }
            }

            remainingBalance = totalAmount - BigDecimal(amount)

            val outputStates = mutableSetOf<DigitalCurrencyState>()

            val inputStates = filteredTokens.stream().map { it.ref }.collect(Collectors.toList())

            var digitalCurrencyInfo: DigitalCurrencyState? = null

            digitalCurrencyInfo = filteredTokens[0].state.contractState

            val receiverTokenState1 = DigitalCurrencyState(
                issuer,
                Utils.getSecureHash(transferTo, digestService),
                digitalCurrencyInfo.name,
                symbol,
                BigDecimal(amount),
                transferTo,
                DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                listOf(senderMember.ledgerKeys.first())
            )
            outputStates.add(receiverTokenState1)
            val receiverTokenState2 = DigitalCurrencyState(
                issuer,
                Utils.getSecureHash(transferTo, digestService),
                digitalCurrencyInfo.name,
                symbol,
                BigDecimal(amount),
                transferTo,
                DigitalCurrencyState.DigitalCurrencyStatus.TRANSFERED,
                listOf(senderMember.ledgerKeys.first())
            )

            outputStates.add(receiverTokenState2)

            if (!remainingBalance.equals(BigDecimal.ZERO)) {
                val senderTokenState = DigitalCurrencyState(
                    issuer,
                    Utils.getSecureHash(transferFrom, digestService),
                    digitalCurrencyInfo.name,
                    symbol,
                    remainingBalance,
                    transferFrom,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(senderMember.ledgerKeys.first())
                )
                outputStates.add(senderTokenState)
            }
            val command = DigitalCurrencyCommands.Transfer(
                sender = transferFrom,
                transfers = listOf(transferTo to BigDecimal(amount)),
                symbol = symbol,
                command = "Transfer"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addCommand(command)
                .addSignatories(listOf(senderMember.ledgerKeys.first()))
            val signedTransaction = txBuilder.toSignedTransaction()

            flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf()))
            flowEngine.subFlow(CompleteDigitalCurrencySubFlow())
        } catch (e: Exception) {
            throw CordaRuntimeException(e.message)
        }
        val json =
            jsonMarshallingService.format(
                Map.of(
                    "Total Amount (Before Transfer): ",
                    totalAmount,
                    "Change: ",
                    remainingBalance,
                    " Total Amount (Transfered): ",
                    totalAmount?.subtract(remainingBalance)
                )
            )
        return json
    }
}
/*
{
    "clientRequestId": "transfer-5",
    "flowClassName": "com.r3.developers.token.workflows.TransferDigitalCurrencyFlow",
    "requestBody": {
        "symbol": "AEDT",
        "transferTo": "CN=Charlie, OU=Test Dept, O=R3, L=London, C=GB",
        "amount": "100",
        "walletAddress": "D",
           "issuer":"SHA-256:3BC51062973C458D5A6F2D8D64A023246354AD7E064B1E4E009EC8A0699A3043"
}
}

 */
//fun signTransactionWithPrivateKey(transactionBuilder: UtxoTransactionBuilder, privateKey: PrivateKey, myIdentity: Party): SignedTransaction {
//    val unsignedTransaction = transactionBuilder.toWireTransaction()
//    val idBytes = unsignedTransaction.id.bytes
//    val signatureBytes = net.corda.v5.crypto.doSign(privateKey, idBytes)
//
//    val signature = DigitalSignature.WithKey(
//        publicKey = Crypto.toSupportedPublicKey(privateKey),
//        bytes = signatureBytes
//    )
//
//    val signedTransaction = transactionBuilder.addSignature(signature)
//    return signedTransaction
//}