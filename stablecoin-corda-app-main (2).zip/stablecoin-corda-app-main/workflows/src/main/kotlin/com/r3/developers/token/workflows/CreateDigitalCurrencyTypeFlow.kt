package com.r3.developers.token.workflows

import com.r3.developers.config.Config
import com.r3.developers.token.contracts.DigitalCurrencyTypeCommands
import com.r3.developers.token.states.DigitalCurrencyTypeState
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.time.Duration
import java.time.Instant

@CordaSerializable
data class CreateDigitalCurrencyTypeArgs(
    val name: String,
    val symbol: String,
)

class CreateDigitalCurrencyTypeFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val (name, symbol) = requestBody.getRequestBodyAs(
                jsonMarshallingService,
                CreateDigitalCurrencyTypeArgs::class.java
            )
            val tokenIssuer = memberLookup.myInfo()

            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("Notary not found")

            val centralBankMember =
                memberLookup.lookup(MemberX500Name.parse(Config.CB))
                    ?: throw CordaRuntimeException("Central Bank not found")

            val tokenState = DigitalCurrencyTypeState(
                name,
                symbol,
               tokenIssuer.name.commonName!!,
                listOf(centralBankMember.ledgerKeys.first(),tokenIssuer.ledgerKeys.first())
            )

            val signatories = setOf(tokenIssuer.ledgerKeys.first(), centralBankMember.ledgerKeys.first())

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addOutputState(tokenState)
                .addCommand(DigitalCurrencyTypeCommands.Create())
                .addSignatories(signatories)
            val signedTransaction = txBuilder.toSignedTransaction()

            return flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf(centralBankMember.name)))
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for request body " + requestBody + " because: " + e.message)
            throw CordaRuntimeException(e.message)
        }
    }
}
/*{
    "clientRequestId": "create-6",
    "flowClassName": "com.r3.developers.token.workflows.CreateDigitalCurrencyTypeFlow",
    "requestBody": {
        "symbol": "USDT",
        "name":"United States Dollar"
}
}*/