package com.r3.developers.token.workflows

import com.r3.developers.config.Config
import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.ClientRequestBody
import net.corda.v5.application.flows.ClientStartableFlow
import net.corda.v5.application.flows.CordaInject
import net.corda.v5.application.flows.FlowEngine
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenClaim
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant

@CordaSerializable
data class TransferDetail(
    val transferTo: String,
    val label: String
)

@CordaSerializable
data class TransferDigitalCurrencyByPercentageArgs(
    val issuer: SecureHash,
    val symbol: String,
    val walletAddressFrom: String,
    val amount: String,
    val transfers: List<TransferDetail>
)

class TransferDigitalCurrencyByPercentage : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        var tokenClaim: TokenClaim? = null
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO

        try {
            val (issuer, symbol, walletAddressFrom, amount, transfers) = requestBody.getRequestBodyAs(
                jsonMarshallingService, TransferDigitalCurrencyByPercentageArgs::class.java
            )

            val senderMember = memberLookup.myInfo()
            val notary = notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                ?: throw CordaRuntimeException("Notary not found")

            val tokens = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 1000, Instant.now()).results

            val filteredTokens = tokens.filter {
                it.state.contractState.walletAddress == walletAddressFrom
            }

            if (filteredTokens.isEmpty()) {
                throw CordaRuntimeException("No token found for $symbol and wallet $walletAddressFrom")
            }

            filteredTokens.forEach {
                totalAmount += it.state.contractState.amount
            }
            if (totalAmount < BigDecimal(amount)) {
                throw CordaRuntimeException("Not enough balance!")
            }

            remainingBalance = totalAmount - BigDecimal(amount)
            val outputStates = mutableSetOf<DigitalCurrencyState>()
            val inputStates = filteredTokens.map { it.ref }
            val digitalCurrencyInfo = filteredTokens[0].state.contractState
            if (remainingBalance.compareTo(BigDecimal.ZERO)!=0) {
                val senderTokenState = DigitalCurrencyState(
                    issuer,
                    Utils.getSecureHash(walletAddressFrom, digestService),
                    digitalCurrencyInfo.name,
                    symbol,
                    remainingBalance,
                    walletAddressFrom,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(senderMember.ledgerKeys.first())
                )
                outputStates.add(senderTokenState)
            }

            val transferDetails = transfers.map { transfer ->
                val percentage = Config.percentages.find { it.first == transfer.label }?.second?.toBigDecimal()
                    ?: throw CordaRuntimeException("Percentage not found for label: ${transfer.label}")

                val transferAmount = BigDecimal(amount).multiply(percentage).divide(BigDecimal(100))

                val receiverTokenState = DigitalCurrencyState(
                    issuer,
                    Utils.getSecureHash(transfer.transferTo, digestService),
                    digitalCurrencyInfo.name,
                    symbol,
                    transferAmount,
                    transfer.transferTo,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(senderMember.ledgerKeys.first())
                )

                outputStates.add(receiverTokenState)

                val receiverTokenState2 = DigitalCurrencyState(
                    issuer,
                    Utils.getSecureHash(transfer.transferTo, digestService),
                    digitalCurrencyInfo.name,
                    symbol,
                    transferAmount,
                    transfer.transferTo,
                    DigitalCurrencyState.DigitalCurrencyStatus.TRANSFERED,
                    listOf(senderMember.ledgerKeys.first())
                )
                outputStates.add(receiverTokenState2)

                transfer.transferTo to transferAmount
            }



            val command = DigitalCurrencyCommands.TransferByPercentage(
                sender = walletAddressFrom,
                transfers = transferDetails,
                symbol = symbol,
                command = "TransferByPercentage"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addCommand(command)
                .addSignatories(listOf(senderMember.ledgerKeys.first()))

            val signedTransaction = txBuilder.toSignedTransaction()
            flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf()))
            flowEngine.subFlow(CompleteDigitalCurrencySubFlow())
        } catch (e: Exception) {
            throw CordaRuntimeException(e.message)
        }

        val json = jsonMarshallingService.format(
            mapOf(
                "Total Amount (Before Transfer)" to totalAmount,
                "Change" to remainingBalance,
                "Total Amount (Transferred)" to totalAmount.subtract(remainingBalance)
            )
        )
        return json
    }
}
/*
{
    "clientRequestId": "transferPercent-2",
    "flowClassName": "com.r3.developers.token.workflows.TransferDigitalCurrencyByPercentage",
    "requestBody": {
    "issuer": "SHA-256:3BC51062973C458D5A6F2D8D64A023246354AD7E064B1E4E009EC8A0699A3043",
    "symbol": "AEDT",
    "walletAddressFrom": "G",
    "amount": "1000",
    "transfers": [
    {
        "transferTo": "G1",
        "label": "BANK"
    },
    {
        "transferTo": "G2",
        "label": "DRIVER"
    },
    {
        "transferTo": "G3",
        "label": "APPLICATION"
    }
    ]
}
}
*/
