package com.r3.developers.tokenized_deposit.workflows

import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositCommands
import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import com.r3.developers.tokenized_deposit.states.TokenizedDepositStatus
import com.r3.developers.utils.Notary
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.*
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.application.messaging.FlowSession
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.StateAndRef
import net.corda.v5.ledger.utxo.UtxoLedgerService
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Instant

@CordaSerializable
data class TransferTokenizedDepositArgs(
    val amount: String,
    val senderAccountNumber: String,
    val counterPartyBeneficiary: String,
    val receiverAccountNumber: String
)

@InitiatingFlow(protocol = "transfer-tokenized-deposit-protocol")
class TransferTokenizedDeposit : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        try {
            val (amount, senderAccountNumber, counterPartyBeneficiary, receiverAccountNumber) = requestBody.getRequestBodyAs(
                jsonMarshallingService,
                TransferTokenizedDepositArgs::class.java
            )
            val senderMember = memberLookup.myInfo()

            val receiverMember = memberLookup.lookup(MemberX500Name.parse(counterPartyBeneficiary))
                ?: throw CordaRuntimeException("Receiver does not exist")

            val notary = Notary(notaryLookup)

            val senderTokenizedDeposits = ledgerService.findUnconsumedStatesByExactType(
                TokenizedDepositState::class.java,
                100,
                Instant.now()
            ).results

            val filteredSenderTokenizedDeposits = senderTokenizedDeposits.filter {
                it.state.contractState.accountNumber == senderAccountNumber
            }
            if (filteredSenderTokenizedDeposits.size != 1) throw CordaRuntimeException("Multiple or zero Tokenized Deposit states with accountNumber \" + senderAccountNumber + \" found")

            val senderTokenizedDeposit = filteredSenderTokenizedDeposits.first().state.contractState
            val newTokenizedBalance = senderTokenizedDeposit.tokenizedBalance.minus(BigDecimal(amount))

            if (newTokenizedBalance < BigDecimal.ZERO) {
                throw CordaRuntimeException("Insufficient Tokenized Balance")
            }

            val receiverSession = flowMessaging.initiateFlow(receiverMember.name)

            receiverSession.send(
                TransferTokenizedDepositArgs(
                    amount,
                    senderAccountNumber,
                    counterPartyBeneficiary,
                    receiverAccountNumber
                )
            )

            val bankMember = memberLookup.lookup(MemberX500Name.parse(senderTokenizedDeposit.bank))
                ?: throw CordaRuntimeException("Bank does not exist")

            val senderOutputTokenizedDeposit = senderTokenizedDeposit.copy(
                TokenizedDepositStatus.UPDATED,
                senderTokenizedDeposit.tokenizedBalance.minus(BigDecimal(amount))
            )

            val command = TokenizedDepositCommands.Transfer(
                senderMember.name.toString(),
                receiverMember.name.toString(),
                BigDecimal(amount),
                senderTokenizedDeposit.tokenizedDepositCurrency,
                "Transfer"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .addInputState(filteredSenderTokenizedDeposits.first().ref)
                .addOutputStates(senderOutputTokenizedDeposit)
                .addCommand(command)
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(java.time.Duration.ofDays(1).toMillis()))
                .addSignatories(senderTokenizedDeposit.participants)

            val signedTransaction = txBuilder.toSignedTransaction()

            return flowEngine.subFlow(FinalizeTokenizedDepositSubFlow(signedTransaction, listOf(bankMember.name)))
        } catch (e: Exception) {
            log.warn("Failed to process utxo flow for session '$requestBody' because:'${e.message}'")
            throw e
        }
    }
}

@CordaSerializable
class ResponderResponse(val inputState: StateAndRef<TokenizedDepositState>?)

@InitiatedBy(protocol = "transfer-tokenized-deposit-protocol")
class TransferTokenizedDepositResponderFlow : ResponderFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @Suspendable
    override fun call(session: FlowSession) {
        try {
            log.info("calling TransferTokenizedDepositResponderFlow")

            val sessionArgs = session.receive(TransferTokenizedDepositArgs::class.java)

            val tokenizedDeposits =
                ledgerService.findUnconsumedStatesByExactType(
                    TokenizedDepositState::class.java,
                    100,
                    Instant.now()
                ).results

            val tokenizedDepositAccountRef = tokenizedDeposits.filter {
                it.state.contractState.accountNumber == sessionArgs.receiverAccountNumber
            }
            if (tokenizedDepositAccountRef.size != 1) throw CordaRuntimeException("Multiple or zero Tokenized Deposit states with accountNumber \" + senderAccountNumber + \" found")

            val tokenizedDepositAccountInput = tokenizedDepositAccountRef.first().state.contractState

            val bankMember = memberLookup.lookup(
                MemberX500Name.parse(tokenizedDepositAccountInput.bank)
            ) ?: throw CordaRuntimeException("Bank not found")


            val outputTokenizedDepositState = tokenizedDepositAccountInput.copy(
                TokenizedDepositStatus.UPDATED,
                tokenizedDepositAccountInput.tokenizedBalance.plus(BigDecimal(sessionArgs.amount))
            )

            val command = TokenizedDepositCommands.Transfer(
                tokenizedDepositAccountInput.beneficiary,
                sessionArgs.counterPartyBeneficiary,
                BigDecimal(sessionArgs.amount),
                tokenizedDepositAccountInput.tokenizedDepositCurrency,
                "Transfer"
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .addInputState(tokenizedDepositAccountRef.first().ref)
                .addOutputState(outputTokenizedDepositState)
                .setNotary(Notary(notaryLookup).name)
                .addSignatories(outputTokenizedDepositState.participants)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(java.time.Duration.ofDays(1).toMillis()))
                .addCommand(command)

            val signedTransaction = txBuilder.toSignedTransaction()

            flowEngine.subFlow(FinalizeTokenizedDepositSubFlow(signedTransaction, listOf(bankMember.name)))
        } catch (e: Exception) {
            log.warn("error TransferTokenizedDepositResponderFlow: " + e.message)
            session.send(ResponderResponse(null))
            throw e
        }
    }
}
