package com.r3.developers.token.workflows

import com.r3.developers.token.contracts.DigitalCurrencyCommands
import com.r3.developers.token.states.DigitalCurrencyState
import com.r3.developers.tokenized_deposit.workflows.Message
import com.r3.developers.tokenized_deposit.workflows.Statuses
import com.r3.developers.utils.Utils
import net.corda.v5.application.crypto.DigestService
import net.corda.v5.application.flows.*
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.application.membership.MemberLookup
import net.corda.v5.application.messaging.FlowMessaging
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.base.types.MemberX500Name
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.common.NotaryLookup
import net.corda.v5.ledger.utxo.UtxoLedgerService
import net.corda.v5.ledger.utxo.token.selection.TokenClaim
import net.corda.v5.ledger.utxo.token.selection.TokenSelection
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.Duration
import java.time.Instant
import java.util.Map
import java.util.stream.Collectors

@CordaSerializable
data class RedeemDigitalCurrencyArgs(
    val symbol: String,
    val issuer: SecureHash,
    val amount: String,
    val walletAddress: String,
    val accountNumber: String,
    val beneficiary: String
)

@CordaSerializable
data class RedeemSessionArgs(
    val symbol: String,
    val amount: String,
    val accountNumber: String,
)

@InitiatingFlow(protocol = "redeem-digital-currency-protocol")

class RedeemDigitalCurrencyFlow : ClientStartableFlow {
    private companion object {
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)
    }

    @CordaInject
    lateinit var jsonMarshallingService: JsonMarshallingService

    @CordaInject
    lateinit var memberLookup: MemberLookup

    @CordaInject
    lateinit var notaryLookup: NotaryLookup

    @CordaInject
    lateinit var tokenSelection: TokenSelection

    @CordaInject
    lateinit var ledgerService: UtxoLedgerService

    @CordaInject
    lateinit var flowEngine: FlowEngine

    @CordaInject
    lateinit var digestService: DigestService

    @CordaInject
    lateinit var flowMessaging: FlowMessaging

    @Suspendable
    override fun call(requestBody: ClientRequestBody): String {
        var tokenClaim: TokenClaim? = null
        var totalAmount = BigDecimal.ZERO
        var remainingBalance = BigDecimal.ZERO

        try {
            val (symbol, issuer, amount, walletAddress, linearId, beneficiary) = requestBody.getRequestBodyAs(
                jsonMarshallingService, RedeemDigitalCurrencyArgs::class.java
            )

            val senderMember = memberLookup.myInfo()
            val beneficiaryMember = memberLookup.lookup(MemberX500Name.parse(beneficiary))
                ?: throw CordaRuntimeException("Beneficiary does not exist")
            val notary =
                notaryLookup.lookup(MemberX500Name.parse("CN=NotaryService, OU=Test Dept, O=R3, L=London, C=GB"))
                    ?: throw CordaRuntimeException("Notary not found")

            val tokens = ledgerService.findUnconsumedStatesByExactType(DigitalCurrencyState::class.java, 1000, Instant.now()).results

            //todo? filter states by minimum amount
            val filteredTokens = tokens.filter {
                it.state.contractState.walletAddress == walletAddress
            }
            if(filteredTokens.isEmpty()){
                throw CordaRuntimeException("No token found for $symbol and wallet $walletAddress")
            }


            val beneficiarySession = flowMessaging.initiateFlow(beneficiaryMember.name)
            beneficiarySession.send(
                RedeemSessionArgs(
                    symbol, amount, linearId
                )
            )

            val response = beneficiarySession.receive(Message::class.java)

            if (response.status == Statuses.FAILED) {
                throw CordaRuntimeException(response.message)
            }

            filteredTokens.forEach {
                if (it.state.contractState.walletAddress == walletAddress) {
                    totalAmount += it.state.contractState.amount
                }
            }

            remainingBalance = totalAmount - BigDecimal(amount)

            val outputStates = mutableSetOf<DigitalCurrencyState>()

            //Get all input states related to the token claim
            val inputStates = filteredTokens.stream().map { it.ref }.collect(Collectors.toList())
            var digitalCurrencyInfo: DigitalCurrencyState? = null

            digitalCurrencyInfo = filteredTokens[0].state.contractState

            val receiverTokenState = DigitalCurrencyState(
                issuer,
                Utils.getSecureHash(walletAddress, digestService),
                digitalCurrencyInfo.name,
                symbol,
                BigDecimal(amount),
                digitalCurrencyInfo.walletAddress,
                DigitalCurrencyState.DigitalCurrencyStatus.REDEEMED,
                listOf(senderMember.ledgerKeys.first())
            )

            outputStates.add(receiverTokenState)

            var senderTokenState: DigitalCurrencyState? = null

            if (!remainingBalance.equals(BigDecimal.ZERO)) {
                senderTokenState = DigitalCurrencyState(
                    issuer,
                    Utils.getSecureHash(walletAddress, digestService),
                    digitalCurrencyInfo.name,
                    symbol,
                    remainingBalance,
                    digitalCurrencyInfo.walletAddress,
                    DigitalCurrencyState.DigitalCurrencyStatus.ISSUED,
                    listOf(senderMember.ledgerKeys.first())
                )
                outputStates.add(senderTokenState)
            }

            val command = DigitalCurrencyCommands.Redeem(
                sender = walletAddress,
                symbol = symbol,
                command = "RedeemDigitalCurrency",
                transfers=listOf("null" to BigDecimal(amount))
            )

            val txBuilder = ledgerService.createTransactionBuilder()
                .setNotary(notary.name)
                .setTimeWindowBetween(Instant.now(), Instant.now().plusMillis(Duration.ofDays(1).toMillis()))
                .addInputStates(inputStates)
                .addOutputStates(outputStates)
                .addCommand(command)
                .addSignatories(listOf(senderMember.ledgerKeys.first()))

            val signedTransaction = txBuilder.toSignedTransaction()

            flowEngine.subFlow(FinalizeTokenSubFlow(signedTransaction, listOf()))
            flowEngine.subFlow(CompleteDigitalCurrencySubFlow())
        } catch (e: Exception) {
            throw CordaRuntimeException(e.message)
        }

        val json = jsonMarshallingService.format(Map.of("Remaining Amount ", remainingBalance))
        return json

    }
}
/*{
    "clientRequestId": "burn-1",
    "flowClassName": "com.r3.developers.token.workflows.RedeemDigitalCurrencyFlow",
    "requestBody": {
        "symbol": "AEDT",
        "issuer": "CN=Alice, OU=Test Dept, O=R3, L=London, C=GB",
        "amount": "100",
        "walletAddress" : "G",
        "accountNumber":"1",
        "beneficiary":"CN=Bob, OU=Test Dept, O=R3, L=London, C=GB"
        }
}*/