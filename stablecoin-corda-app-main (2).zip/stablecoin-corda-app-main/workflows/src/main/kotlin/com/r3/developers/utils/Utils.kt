package com.r3.developers.utils

import net.corda.v5.application.crypto.DigestService
import net.corda.v5.base.annotations.Suspendable
import net.corda.v5.crypto.DigestAlgorithmName
import net.corda.v5.crypto.SecureHash

object Utils {
    @Suspendable
    fun getSecureHash(commonName: String, digestService: DigestService): SecureHash {
        return digestService.hash(commonName.toByteArray(), DigestAlgorithmName.SHA2_256)
    }
}