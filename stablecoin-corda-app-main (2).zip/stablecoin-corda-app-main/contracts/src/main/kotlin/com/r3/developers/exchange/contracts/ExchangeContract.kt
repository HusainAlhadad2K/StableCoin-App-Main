package com.r3.developers.exchange.contracts

import com.r3.developers.exchange.states.ExchangeState
import com.r3.developers.exchange.states.ExchangeStatus
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction
import java.math.BigDecimal

class ExchangeContract : Contract {
    internal companion object {
        const val COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE = "There should be one and only one input state."
        const val AMOUNT_SHOULD_BE_MORE_THAN_ZERO = "convertedAmount or convertedFromAmount can't be less than 0."
        const val REJECTEDBY_CANT_BE_NULL = "rejectedBy can't be NULL."
        const val INPUT_STATUS_MUST_BE_PROPOSED = "input exchange state status must be proposed."

    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        val inputStates = transaction.getInputStates(ExchangeState::class.java)
        val outputStates = transaction.getOutputStates(ExchangeState::class.java)

        if (inputStates.isNotEmpty()) {
            require(
                inputStates.first().convertedAmount > BigDecimal.ZERO || inputStates.first().convertingFromAmount > BigDecimal.ZERO
            ) {
                AMOUNT_SHOULD_BE_MORE_THAN_ZERO
            }
        }

        when (val command = transaction.commands.first()) {
            is ExchangeCommands.Propose -> {

            }

            is ExchangeCommands.Accept -> {
                require(inputStates.size == 1) {
                    COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE
                }

                val inputState=inputStates[0]

                require(inputState.status==ExchangeStatus.PROPOSED) {
                    INPUT_STATUS_MUST_BE_PROPOSED
                }
            }

            is ExchangeCommands.Reject -> {
                require(inputStates.size == 1) {
                    COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE
                }
                val inputState=inputStates[0]

                require(inputState.status==ExchangeStatus.PROPOSED) {
                    INPUT_STATUS_MUST_BE_PROPOSED
                }
                require(!outputStates.first().rejectedBy.isNullOrEmpty()) {
                    REJECTEDBY_CANT_BE_NULL
                }
            }

            else -> {
                throw IllegalArgumentException("Incorrect type of Exchange commands: ${command::class.java.name}")
            }
        }
    }
}