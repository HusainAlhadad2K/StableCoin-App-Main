package com.r3.developers.tokenized_deposit.states

import com.r3.developers.tokenized_deposit.contracts.TokenizedDepositContract
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import net.corda.v5.ledger.utxo.StateAndRef
import net.corda.v5.ledger.utxo.query.VaultNamedQueryFactory
import net.corda.v5.ledger.utxo.query.VaultNamedQueryFilter
import net.corda.v5.ledger.utxo.query.VaultNamedQueryStateAndRefFilter
import net.corda.v5.ledger.utxo.query.VaultNamedQueryStateAndRefTransformer
import net.corda.v5.ledger.utxo.query.json.ContractStateVaultJsonFactory
import net.corda.v5.ledger.utxo.query.registration.VaultNamedQueryBuilderFactory
import java.math.BigDecimal
import java.security.PublicKey
import java.util.*

@BelongsToContract(TokenizedDepositContract::class)
data class TokenizedDepositState(
    val bank: String,
    val tokenizedBalance: BigDecimal,
    val beneficiary: String,
    val commercialDepositCurrency: String,
    val tokenizedDepositCurrency: String,
    val accountNumber: String,
    val accountType: AccountType,
    val status: TokenizedDepositStatus,
    private val participants: List<PublicKey>
) : ContractState {
    override fun getParticipants(): List<PublicKey> {
        return participants
    }

    fun copy(status: TokenizedDepositStatus, tokenizedbalance: BigDecimal): TokenizedDepositState {
        return TokenizedDepositState(
            beneficiary = this.beneficiary,
            status = status,
            accountNumber = this.accountNumber,
            accountType = this.accountType,
            bank = this.bank,
            tokenizedDepositCurrency = this.tokenizedDepositCurrency,
            commercialDepositCurrency = this.tokenizedDepositCurrency,
            tokenizedBalance = tokenizedbalance,
            participants = this.participants
        )
    }
}

@CordaSerializable
enum class TokenizedDepositStatus {
    CREATED,
    UPDATED,
    CLOSED
}

@CordaSerializable
enum class AccountType {
    TOKENIZED_CHECKING, COMMERCIAL_CHECKING, TOKENIZED_SAVINGS, COMMERCIAL_SAVINGS, TOKENIZED_CORPORATE, COMMERCIAL_CORPORATE, OTHER
}

fun getAccountType(accountTypeString: String): AccountType {
    return try {
        enumValueOf<AccountType>(accountTypeString.uppercase(Locale.getDefault()))
    } catch (e: IllegalArgumentException) {
        throw IllegalArgumentException("Invalid account type: $accountTypeString")
    }
}

class TokenizedDepositJsonFactory : ContractStateVaultJsonFactory<TokenizedDepositState> {
    override fun getStateType(): Class<TokenizedDepositState> {
        return TokenizedDepositState::class.java
    }

    override fun create(state: TokenizedDepositState, jsonMarshallingService: JsonMarshallingService): String {
        return jsonMarshallingService.format(state)
    }
}

class TokenizedDepositQuery : VaultNamedQueryFactory {
    override fun create(vaultNamedQueryBuilderFactory: VaultNamedQueryBuilderFactory) {
        vaultNamedQueryBuilderFactory.create("TokenizedDepositQuery")
            .whereJson(
                "WHERE visible_states.custom_representation -> 'com.r3.developers.tokenized_deposit.states.TokenizedDepositState' IS NOT NULL"
            )
            .map(TokenizedDepositTransform())
            .register()
    }
}
class TokenizedDepositTransform : VaultNamedQueryStateAndRefTransformer<TokenizedDepositState, SecureHash> {
    override fun transform(data: StateAndRef<TokenizedDepositState>, parameters: MutableMap<String, Any>): SecureHash {
        return data.ref.transactionId
    }
}