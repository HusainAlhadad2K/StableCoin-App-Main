package com.r3.developers.tokenized_deposit.contracts

import net.corda.v5.ledger.utxo.Command
import java.math.BigDecimal

interface TokenizedDepositCommands : Command {
    class CreateDeposit(
        val sender: String?,
        val recipient: String?,
        val amount: BigDecimal,
        val symbol: String,
        val command: String
    ) : TokenizedDepositCommands

    class RedeemDeposit(
        val sender: String?,
        val recipient: String?,
        val amount: BigDecimal,
        val symbol: String,
        val command: String
    ) : TokenizedDepositCommands

    class AddToken(
        val sender: String?,
        val recipient: String?,
        val amount: BigDecimal,
        val symbol: String,
        val command: String
    ) : TokenizedDepositCommands
    class ConsumeToken(
        val sender: String?,
        val recipient: String?,
        val amount: BigDecimal,
        val symbol: String,
        val command: String
    ) : TokenizedDepositCommands

    class Transfer(
        val sender: String?,
        val recipient: String?,
        val amount: BigDecimal,
        val symbol: String,
        val command: String
    ) : TokenizedDepositCommands

    class CloseDeposit : TokenizedDepositCommands
}



