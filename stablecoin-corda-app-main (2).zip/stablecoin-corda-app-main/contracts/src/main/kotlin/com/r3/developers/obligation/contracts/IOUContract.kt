package com.r3.developers.obligation.contracts

import com.r3.developers.obligation.states.IOUState
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction

class IOUContract : Contract {

    //IOU Commands
    internal companion object {
        const val CONTRACT_RULE_SINGLE_COMMAND = "Exactly one DigitalCurrencyCommands command must be present in the transaction."
        const val COMMAND_SHOULD_HAVE_NO_INPUT_STATE = "There should be no input states."
        const val COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE = "There should be one and only one output state."

    }

    override fun verify(transaction: UtxoLedgerTransaction) {

        // Ensures that there is only one command in the transaction
        val command = transaction.getCommands(IOUCommands::class.java).singleOrNull()
            ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_COMMAND)
        val outputStates = transaction.getOutputStates(IOUState::class.java)
        val inputStates = transaction.getInputStates(IOUState::class.java)

        // Switches case based on the command
        when(command) {

            is IOUCommands.Settle -> {
            }
            // Rules applied only to transactions with the Transfer Command.
            is IOUCommands.Transfer -> {
            }
            is IOUCommands.Issue -> {
            }
            is IOUCommands.Reject -> {
            }
            is IOUCommands.Propose -> {
                require(outputStates.size == 1) {
                    COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE
                }
                require(inputStates.isEmpty()) { COMMAND_SHOULD_HAVE_NO_INPUT_STATE }
            }
            is IOUCommands.Complete->{

            }
            else -> {
                throw CordaRuntimeException("Command not allowed.")
            }
        }
    }

    // Helper function to allow writing constraints in the Corda 4 '"text" using (boolean)' style
    private infix fun String.using(expr: Boolean) {
        if (!expr) throw CordaRuntimeException("Failed requirement: $this")
    }

    // Helper function to allow writing constraints in '"text" using {lambda}' style where the last expression
    // in the lambda is a boolean.
    private infix fun String.using(expr: () -> Boolean) {
        if (!expr.invoke()) throw CordaRuntimeException("Failed requirement: $this")
    }
}