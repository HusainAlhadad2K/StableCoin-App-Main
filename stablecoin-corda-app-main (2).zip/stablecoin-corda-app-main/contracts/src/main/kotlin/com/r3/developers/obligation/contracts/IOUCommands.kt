package com.r3.developers.obligation.contracts

import net.corda.v5.ledger.utxo.Command
import java.math.BigDecimal

interface IOUCommands : Command {
    class Settle ( val command: String,val borrower: String?, val lenders: List<String>?, val amount: BigDecimal, val symbol: String, val linearId: String?): IOUCommands
    class Transfer ( val command: String,val borrower: String?, val lenders: List<String>?, val amount: BigDecimal, val symbol: String, val linearId: String?): IOUCommands
    class Complete (): IOUCommands
    class Propose( val command: String,val borrower: String?, val lenders: List<String>?, val amount: BigDecimal, val symbol: String, val linearId: String?) : IOUCommands
    class Issue( val command: String,val borrower: String?, val lenders: List<String>?, val amount: BigDecimal, val symbol: String,val linearId: String?): IOUCommands
    class Reject( val command: String,val borrower: String?, val lenders: List<String>?, val amount: BigDecimal, val symbol: String, val linearId: String?): IOUCommands

}