package com.r3.developers.token.states

import com.r3.developers.token.contracts.DigitalCurrencyContract
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import net.corda.v5.ledger.utxo.StateAndRef
import net.corda.v5.ledger.utxo.observer.*
import net.corda.v5.ledger.utxo.query.VaultNamedQueryFactory
import net.corda.v5.ledger.utxo.query.VaultNamedQueryStateAndRefTransformer
import net.corda.v5.ledger.utxo.query.json.ContractStateVaultJsonFactory
import net.corda.v5.ledger.utxo.query.registration.VaultNamedQueryBuilderFactory
import java.math.BigDecimal
import java.security.PublicKey

@BelongsToContract(DigitalCurrencyContract::class)
data class DigitalCurrencyState(
    val issuer: SecureHash,
    val owner: SecureHash,
    val name : String,
    val symbol: String,
    val amount: BigDecimal,
    val walletAddress: String,
    val status: DigitalCurrencyStatus,
    private val participants: List<PublicKey>
) : ContractState {
    override fun getParticipants(): List<PublicKey> {
        return participants
    }
    @CordaSerializable
    enum class DigitalCurrencyStatus {
        ISSUED,
        REDEEMED,
        TRANSFERED
    }
    fun copy(status: DigitalCurrencyStatus): DigitalCurrencyState {
        return DigitalCurrencyState(
            issuer = this.issuer,
            owner = this.owner,
            name = this.name,
            symbol = this.symbol,
            amount = this.amount,
            walletAddress = this.walletAddress,
            status = status,
            participants = this.participants
        )
    }
}


class TokenStateObserver : UtxoTokenTransactionStateObserver<DigitalCurrencyState> {
    override fun getStateType(): Class<DigitalCurrencyState> {
        return DigitalCurrencyState::class.java
    }

    override fun onCommit(context: TokenStateObserverContext<DigitalCurrencyState>): UtxoToken {
        val state = context.stateAndRef.state.contractState
        val poolKey = UtxoTokenPoolKey(DigitalCurrencyState::class.java.name, state.issuer, state.symbol)
        return UtxoToken(poolKey, state.amount, UtxoTokenFilterFields(null, state.owner))
    }
    class DigitalCurrencyStateJsonFactory : ContractStateVaultJsonFactory<DigitalCurrencyState> {
        override fun getStateType(): Class<DigitalCurrencyState> = DigitalCurrencyState::class.java
        override fun create(state: DigitalCurrencyState, jsonMarshallingService: JsonMarshallingService): String {
            return jsonMarshallingService.format(state)
        }
    }
    class DigitalCurrencyQueryTransformer : VaultNamedQueryStateAndRefTransformer<DigitalCurrencyState, SecureHash> {
        override fun transform(data: StateAndRef<DigitalCurrencyState>, parameters: MutableMap<String, Any>): SecureHash {
            return data.ref.transactionId
        }
    }


    class DigitalCurrencyQueryFactory : VaultNamedQueryFactory {
        override fun create(vaultNamedQueryBuilderFactory: VaultNamedQueryBuilderFactory) {
            vaultNamedQueryBuilderFactory.create("CUSTOM_QUERY2")
                .whereJson(
                    "WHERE visible_states.custom_representation -> 'com.r3.developers.token.states.DigitalCurrencyState' IS NOT NULL"
                )
                .map(DigitalCurrencyQueryTransformer())
                .register()
        }
    }

}