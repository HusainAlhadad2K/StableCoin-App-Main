package com.r3.developers.tokenized_deposit.contracts

import com.r3.developers.tokenized_deposit.states.TokenizedDepositState
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction
import java.math.BigDecimal

class TokenizedDepositContract : Contract {
    internal companion object {
        const val COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE = "There should be one and only one input state."
        const val CONTRACT_RULE_SINGLE_COMMAND =
            "Exactly one TokenizedDepositCommands command must be present in the transaction."
        const val CONTRACT_RULE_UNRECOGNIZED_COMMAND = "An unrecognized Command is given:"
        const val CONTRACT_RULE_SINGLE_OUTPUT =
            "The TokenizedDeposit transaction requires a single output state to be created."
        const val CREATEDEPOSIT_COMMAND_SHOULD_HAVE_NO_INPUT_STATES =
            "When command is CreateDeposit there should be no input states."
        const val BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO =
            "tokenizedBalance and commercialBalance should be greater or equal to 0."
        const val OUTPUT_TOKENIZEDBALANCE_MUST_BE_GREATER_THAN_INPUT_TOKENIZEDBALANCE =
            "OUTPUT tokenizedBalance MUST BE GREATER THAN INPUT tokenizedBalance"
        const val OUTPUT_TOKENIZEDBALANCE_MUST_BE_LESS_THAN_INPUT_TOKENIZEDBALANCE =
            "OUTPUT tokenizedBalance MUST BE LESS THAN INPUT tokenizedBalance"
        const val OUTPUT_TOKENIZEDBALANCE_MUST_BE_EQUAL_TO_INPUT_TOKENIZEDBALANCE =
            "OUTPUT tokenizedBalance MUST BE EQUAL TO INPUT tokenizedBalance"
        const val CONTRACT_RULE_NO_OUTPUTS = "No output states should be present."
    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        val command = transaction.getCommands(TokenizedDepositCommands::class.java).singleOrNull()
            ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_COMMAND)

        when (command) {
            is TokenizedDepositCommands.CreateDeposit -> {
                val output = transaction.getOutputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_OUTPUT)
                BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO using { output.tokenizedBalance >= BigDecimal(0) }
                CREATEDEPOSIT_COMMAND_SHOULD_HAVE_NO_INPUT_STATES using { transaction.inputContractStates.isEmpty() }
            }

            is TokenizedDepositCommands.RedeemDeposit -> {
                val output = transaction.getOutputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_OUTPUT)
                val input = transaction.getInputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE)
                BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO using { output.tokenizedBalance >= BigDecimal(0) }
                OUTPUT_TOKENIZEDBALANCE_MUST_BE_EQUAL_TO_INPUT_TOKENIZEDBALANCE using { input.tokenizedBalance == output.tokenizedBalance }
            }


            is TokenizedDepositCommands.AddToken -> {
                val output = transaction.getOutputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_OUTPUT)
                val input = transaction.getInputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE)
                OUTPUT_TOKENIZEDBALANCE_MUST_BE_GREATER_THAN_INPUT_TOKENIZEDBALANCE using { output.tokenizedBalance > input.tokenizedBalance }
                BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO using { output.tokenizedBalance >= BigDecimal(0) }
            }

            is TokenizedDepositCommands.ConsumeToken -> {
                val output = transaction.getOutputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_OUTPUT)
                val input = transaction.getInputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE)
                OUTPUT_TOKENIZEDBALANCE_MUST_BE_LESS_THAN_INPUT_TOKENIZEDBALANCE using { output.tokenizedBalance < input.tokenizedBalance }
                BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO using { output.tokenizedBalance >= BigDecimal(0) }

            }

            is TokenizedDepositCommands.Transfer -> {
                val output = transaction.getOutputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_OUTPUT)
                val input = transaction.getInputStates(TokenizedDepositState::class.java).singleOrNull()
                    ?: throw CordaRuntimeException(COMMAND_SHOULD_HAVE_ONLY_ONE_INPUT_STATE)
                OUTPUT_TOKENIZEDBALANCE_MUST_BE_LESS_THAN_INPUT_TOKENIZEDBALANCE using { output.tokenizedBalance < input.tokenizedBalance }
                BALANCES_SHOULD_BE_GREATER_THAN_OR_EQUAL_TO_ZERO using { output.tokenizedBalance >= BigDecimal(0) }
            }

            is TokenizedDepositCommands.CloseDeposit -> {
                val outputs = transaction.getOutputStates(TokenizedDepositState::class.java)

                if (outputs.isNotEmpty()) {
                    throw CordaRuntimeException(CONTRACT_RULE_NO_OUTPUTS)
                }
            }

            else -> {
                throw IllegalArgumentException("$CONTRACT_RULE_UNRECOGNIZED_COMMAND: ${command::class.java.name}")
            }
        }
    }

    private infix fun String.using(expr: () -> Boolean) {
        if (!expr.invoke()) throw CordaRuntimeException("Failed contract requirement: $this")
    }
}