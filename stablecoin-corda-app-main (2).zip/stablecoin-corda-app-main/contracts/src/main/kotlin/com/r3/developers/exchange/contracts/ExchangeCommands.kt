package com.r3.developers.exchange.contracts

import net.corda.v5.ledger.utxo.Command

interface ExchangeCommands : Command {
    class Propose : Command
    class Accept : Command
    class Reject : Command
}