package com.r3.developers.token.states

import com.r3.developers.token.contracts.DigitalCurrencyTypeContract
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import java.security.PublicKey

@BelongsToContract(DigitalCurrencyTypeContract::class)
data class DigitalCurrencyTypeState(
    val name : String,
    val symbol: String,
    val issuer: String,
    private val participants: List<PublicKey>
) : ContractState {
    override fun getParticipants(): List<PublicKey> {
        return participants
    }


}







