package com.r3.developers.token.contracts

import com.r3.developers.token.states.DigitalCurrencyTypeState
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction

class DigitalCurrencyTypeContract : Contract {
    internal companion object {
        const val COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE = "There should be one and only one output state."
        const val CONTRACT_RULE_SINGLE_COMMAND = "Exactly one DigitalCurrencyTypeCommands command must be present in the transaction."
    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        val command = transaction.getCommands(DigitalCurrencyTypeCommands::class.java).singleOrNull()
            ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_COMMAND)

        val outputStates = transaction.getOutputStates(DigitalCurrencyTypeState::class.java)

        when (command) {
            is DigitalCurrencyTypeCommands.Create -> {
                require(outputStates.size == 1) {
                    COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE

                }
            }



            else -> {
                throw IllegalArgumentException("Incorrect type of DigitalCurrencyType commands: ${command::class.java.name}")
            }
        }
    }
}