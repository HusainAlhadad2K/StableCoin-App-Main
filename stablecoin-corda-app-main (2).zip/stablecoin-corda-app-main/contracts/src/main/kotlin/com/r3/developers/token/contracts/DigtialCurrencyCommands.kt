package com.r3.developers.token.contracts

import net.corda.v5.ledger.utxo.Command
import java.math.BigDecimal

interface DigitalCurrencyCommands : Command {


    class Issue (val sender: String?, val transfers: List<Pair<String, BigDecimal>>?, val symbol: String, val command: String): DigitalCurrencyCommands
    class Transfer (val sender: String?, val transfers:List<Pair<String, BigDecimal>>?, val symbol: String, val command: String): DigitalCurrencyCommands
    class Redeem (val sender: String?, val transfers: List<Pair<String, BigDecimal>>?,val symbol: String, val command: String): DigitalCurrencyCommands
    class Complete (): DigitalCurrencyCommands
    class TransferByPercentage (val sender: String?, val symbol: String, val command: String,val transfers: List<Pair<String, BigDecimal>>?): DigitalCurrencyCommands


}
