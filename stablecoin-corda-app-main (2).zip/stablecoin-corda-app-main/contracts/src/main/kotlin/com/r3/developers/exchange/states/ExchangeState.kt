package com.r3.developers.exchange.states

import com.r3.developers.exchange.contracts.ExchangeContract
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import java.math.BigDecimal
import java.security.PublicKey
import java.util.*


@BelongsToContract(ExchangeContract::class)
data class ExchangeState(
    val issuerFrom: String,
    val issuerTo: String,
    val initiator: String,
    val recipient: String,
    val convertingFrom: String,
    val convertingTo: String,
    val exchangeRate: BigDecimal,
    val convertingFromAmount: BigDecimal,
    val convertedAmount: BigDecimal,
    val rejectedBy: String?,
    val linearId: UUID,
    val status: ExchangeStatus,
    private val participants: List<PublicKey>
) : ContractState {
    override fun getParticipants(): List<PublicKey> {
        return participants
    }
    fun copy(status: ExchangeStatus,rejectedBy:String? ): ExchangeState {
        return ExchangeState(
            initiator = this.initiator,
            status = status,
            recipient = this.recipient,
            convertingFromAmount = this.convertingFromAmount,
            convertingFrom = this.convertingFrom,
            convertingTo = this.convertingTo,
            convertedAmount = this.convertedAmount,
            linearId = this.linearId,
            issuerFrom = this.issuerFrom,
            issuerTo = this.issuerTo,
            participants = this.participants,
            exchangeRate=this.exchangeRate,
            rejectedBy=rejectedBy
        )
    }
}
@CordaSerializable
enum class ExchangeStatus{
    PROPOSED,
    DENIED,
    APPROVED
}