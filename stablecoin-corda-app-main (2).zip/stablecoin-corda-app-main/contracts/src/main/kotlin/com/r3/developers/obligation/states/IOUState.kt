package com.r3.developers.obligation.states

import com.r3.developers.obligation.contracts.IOUContract
import net.corda.v5.application.marshalling.JsonMarshallingService
import net.corda.v5.base.annotations.CordaSerializable
import net.corda.v5.crypto.SecureHash
import net.corda.v5.ledger.utxo.BelongsToContract
import net.corda.v5.ledger.utxo.ContractState
import net.corda.v5.ledger.utxo.StateAndRef
import net.corda.v5.ledger.utxo.query.VaultNamedQueryFactory
import net.corda.v5.ledger.utxo.query.VaultNamedQueryStateAndRefTransformer
import net.corda.v5.ledger.utxo.query.json.ContractStateVaultJsonFactory
import net.corda.v5.ledger.utxo.query.registration.VaultNamedQueryBuilderFactory
import java.math.BigDecimal
import java.security.PublicKey
import java.util.*

//Link with the Contract class

@BelongsToContract(IOUContract::class)
data class IOUState(
    val issuer: SecureHash,
    val symbol: String,
    val amount: BigDecimal,
    val lenders: List<Pair<String, BigDecimal>>,
    val borrower: String,
    val paid: BigDecimal,
    val linearId: UUID,
    val status: IOUStatus,
    private val participants: List<PublicKey>
) : ContractState {

    //Helper method for settle flow
    fun pay(amountToPay: BigDecimal) : IOUState {
        if (paid + amountToPay >= amount)
            return IOUState(
                issuer,
                symbol,
                amount,
                lenders,
                borrower,
                amount,
                linearId,
                IOUStatus.PAID,
                participants
            )
        else
            return IOUState(
                issuer,
                symbol,
                amount,
                lenders,
                borrower,
                paid + amountToPay,
                linearId,
                status,
                participants
            )
    }

    //Helper method for transfer flow
    fun withNewLender(newLender: Pair<String, BigDecimal>): IOUState {
        val updatedLenders = lenders + newLender
        return IOUState(
            issuer,
            symbol,
            amount,
            updatedLenders,
            borrower,
            paid,
            linearId,
            status,
            participants
        )
    }
    fun changeStatus(newStatus: IOUStatus) : IOUState {
        return IOUState(issuer, symbol, amount,lenders,borrower,paid,linearId,newStatus,participants)
    }

    override fun getParticipants(): List<PublicKey> {
        return participants
    }
    @CordaSerializable
    enum class IOUStatus {
        PROPOSED,
        ISSUED,
        PAID
    }

    class IOUStateJsonFactory : ContractStateVaultJsonFactory<IOUState> {
        override fun getStateType(): Class<IOUState> = IOUState::class.java
        override fun create(state: IOUState, jsonMarshallingService: JsonMarshallingService): String {
            return jsonMarshallingService.format(state)
        }
    }
    class IOUQueryTransformer : VaultNamedQueryStateAndRefTransformer<IOUState, SecureHash> {
        override fun transform(data: StateAndRef<IOUState>, parameters: MutableMap<String, Any>): SecureHash {
            return data.ref.transactionId
        }
    }


    class IOUQueryFactory : VaultNamedQueryFactory {
        override fun create(vaultNamedQueryBuilderFactory2: VaultNamedQueryBuilderFactory) {
            vaultNamedQueryBuilderFactory2.create("CUSTOM_QUERY4")
                .whereJson(
                    "WHERE visible_states.custom_representation -> 'com.r3.developers.obligation.states.IOUState' IS NOT NULL"
                )
                .map(IOUQueryTransformer())
                .register()
        }
    }

}