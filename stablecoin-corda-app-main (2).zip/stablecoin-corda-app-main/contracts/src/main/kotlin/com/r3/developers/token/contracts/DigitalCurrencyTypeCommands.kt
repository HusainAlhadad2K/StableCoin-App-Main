package com.r3.developers.token.contracts

import net.corda.v5.ledger.utxo.Command

interface DigitalCurrencyTypeCommands : Command {
    class Create : DigitalCurrencyTypeCommands

}
