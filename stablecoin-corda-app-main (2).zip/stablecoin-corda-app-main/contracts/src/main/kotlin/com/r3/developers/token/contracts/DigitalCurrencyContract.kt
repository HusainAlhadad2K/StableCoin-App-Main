package com.r3.developers.token.contracts

import com.r3.developers.token.states.DigitalCurrencyState
import net.corda.v5.base.exceptions.CordaRuntimeException
import net.corda.v5.ledger.utxo.Contract
import net.corda.v5.ledger.utxo.transaction.UtxoLedgerTransaction
import org.slf4j.LoggerFactory
import java.math.BigDecimal

class DigitalCurrencyContract : Contract {
    internal companion object {
        const val COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE = "There should be one and only one output state."
        const val AMOUNT_SHOULD_BE_MORE_THAN_ZERO = "Amount should be more than 0."
        const val CONTRACT_RULE_SINGLE_COMMAND = "Exactly one DigitalCurrencyCommands command must be present in the transaction."
        const val COMMAND_SHOULD_HAVE_AT_MOST_THREE_OUTPUT_STATE = "There should be at most three output states."
        const val COMMAND_SHOULD_HAVE_NO_OUTPUT_STATE = "There should be no output states."
        const val COMMAND_SHOULD_HAVE_AT_MOST_TWO_OUTPUT_STATE = "There should be at most three output states."
        const val COMMAND_SHOULD_HAVE_NO_INPUT_STATE = "There should be no input states."
        const val COMMAND_SHOULD_HAVE_EXACTLY_ONE_INPUT_STATE = "There should be one and only one input states."
        const val COMMAND_MUST_HAVE_INPUT_STATE = "There should be input states."
        const val INPUT_AMOUNT_MUST_BE_EQUAL_OUTPUT_AMOUNT="In Transfer/Redeem, the amount of input tokens MUST EQUAL the amount of output tokens. In other words, you \" +\n" +
                "                            \"cannot create or destroy value when moving tokens."
        val log = LoggerFactory.getLogger(this::class.java.enclosingClass)

    }

    override fun verify(transaction: UtxoLedgerTransaction) {
        val command = transaction.getCommands(DigitalCurrencyCommands::class.java).singleOrNull()
            ?: throw CordaRuntimeException(CONTRACT_RULE_SINGLE_COMMAND)

        val outputStates = transaction.getOutputStates(DigitalCurrencyState::class.java)
        val inputStates = transaction.getInputStates(DigitalCurrencyState::class.java)

        if (outputStates.isNotEmpty()) {
            for (state in outputStates) {
                log.info("aaaAmount: ${state.amount}")

                require(state.amount > BigDecimal.ZERO) {
                    AMOUNT_SHOULD_BE_MORE_THAN_ZERO
                }
            }
        }
        when (command) {
            is DigitalCurrencyCommands.Transfer -> {

                require(inputStates.isNotEmpty()) { COMMAND_MUST_HAVE_INPUT_STATE }
               var inputAmount=BigDecimal.ZERO
                var outputAmount=BigDecimal.ZERO
                val outputStates1=outputStates.filter{it.status ==DigitalCurrencyState.DigitalCurrencyStatus.ISSUED
                }
               inputStates.forEach{
                   inputAmount+= it.amount
               }
                outputStates1.forEach{
                    outputAmount+= it.amount
                }
                log.info("Input Amount: $inputAmount, Output Amount: $outputAmount")
//                require(inputAmount == outputAmount) {
//                    INPUT_AMOUNT_MUST_BE_EQUAL_OUTPUT_AMOUNT
//                }
            }

            is DigitalCurrencyCommands.Issue -> {
                require(outputStates.size == 1) {
                    COMMAND_SHOULD_HAVE_ONLY_ONE_OUTPUT_STATE
                }
                require(inputStates.isEmpty()) { COMMAND_SHOULD_HAVE_NO_INPUT_STATE }

            }

            is DigitalCurrencyCommands.Redeem -> {

                require(outputStates.size <= 2) {
                    COMMAND_SHOULD_HAVE_AT_MOST_TWO_OUTPUT_STATE
                }
                require(inputStates.isNotEmpty()) { COMMAND_MUST_HAVE_INPUT_STATE }

                var inputAmount=BigDecimal.ZERO
                var outputAmount=BigDecimal.ZERO

                inputStates.forEach{
                    inputAmount+= it.amount
                }
                outputStates.forEach{
                    outputAmount+= it.amount
                }
                require(inputAmount == outputAmount) {
                    INPUT_AMOUNT_MUST_BE_EQUAL_OUTPUT_AMOUNT
                }

            }
            is DigitalCurrencyCommands.Complete -> {

                require(outputStates.isEmpty()) {
                    COMMAND_SHOULD_HAVE_NO_OUTPUT_STATE
                }
            }
            is DigitalCurrencyCommands.TransferByPercentage -> {

            }
            else -> {
                throw IllegalArgumentException("Incorrect type of DigitalCurrency commands: ${command::class.java.name}")
            }
        }
    }
}